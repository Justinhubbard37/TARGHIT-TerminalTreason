﻿# Specification: Phase 1 - UI Core & Theme Integration

## Overview
This track focuses on establishing the foundational UI state and visual identity of the Neon Void Terminal. It transitions the existing "Forest Terminal" to the "Amber Synthwave Noir" aesthetic and wires basic interactions using mock data, adhering to the "local-first" and "hard-lock routing" principles.

## Requirements
- **Theme Enforcement:** Apply #0A0C10, #141824, #404656, #2F80ED, #E05B3C, #F2F4F8 to all components.
- **State Management:** Implement basic state for session selection, provider toggle (Local/Cloud), and message history.
- **Mock Gateway:** Simulate a localhost gateway response for "Send Message" and "Inspector" panels.
- **Cloud Safety UI:** Implement the confirmation modal for cloud requests (Gemini) with `Confirm` button and `Shift+Enter` support.
- **Routing Lock:** Ensure all mock "network" calls target `127.0.0.1`.

## Success Criteria
- Existing layout preserved exactly.
- All colors match the Amber Synthwave Noir palette.
- Message list renders mock AI responses.
- Inspector shows mock JSON payloads with Electric Blue/Paper White highlighting.
