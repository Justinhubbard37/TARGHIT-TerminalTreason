# Implementation Plan: Phase 1 - UI Core & Theme Integration

## Phase 1: Theme & State Foundation
- [x] Task: Define Global CSS Variables 93edcc4
    - [ ] Create/Update `index.css` with the Amber Synthwave Noir palette tokens.
    - [ ] Apply base background and typography colors.
- [x] Task: Initialize UI State d4ff2c8
    - [ ] Implement React Context/Hooks for `activeSession`, `currentProvider`, and `messages`.
    - [ ] Set `Local` as the default provider.
- [x] Task: Apply Theme to Existing Components d1525f6
    - [ ] Update `App.tsx` and `Shared.tsx` to use CSS variables for all surfaces, borders, and text.
    - [ ] Enforce Electric Blue (#2F80ED) for focus states.

## Phase 2: Interaction Wiring (Mock)
- [x] Task: Implement Message Flow 02e5aef
    - [ ] Wire the message input to add user messages to the state.
    - [ ] Implement a mock response trigger that simulates a localhost gateway call.
- [x] Task: Create Cloud Confirmation Modal 7de4468
    - [ ] Build the high-contrast modal for cloud selection.
    - [ ] Wire the "Confirm" button and `Shift+Enter` key listener.
- [x] Task: Populate Inspector & Logs 5b185e0
    - [ ] Wire the side panels to display mock request/response data from the current session.
    - [ ] Apply syntax highlighting using palette tokens.

## Phase 3: Finalization & Verification
- [x] Task: Conductor - User Manual Verification 'Phase 1 - UI Core & Theme Integration' (Protocol in workflow.md) [checkpoint: 9b3de95]
