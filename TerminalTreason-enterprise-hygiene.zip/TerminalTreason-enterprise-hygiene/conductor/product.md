﻿# Product Definition: Neon Void Terminal

## Vision & Purpose
Neon Void Terminal is a local-first, terminal-style AI chat cockpit designed primarily for personal use by a solo founder/power user. It provides a high-performance, keyboard-centric environment for intensive AI work, focusing on speed, deep transparency, and granular control over model orchestration. While built for personal utility now, it may be released to a wider audience of solo builders later.

## Target Audience
- **Primary:** The creator (solo founder/power user) requiring a high-velocity, keyboard-first workflow.
- **Secondary:** Future release for other developers and solo builders who value privacy and low-friction AI interactions.

## Core Goals
- **Low Latency & High Velocity:** Instantaneous responses and keyboard-driven flow.
- **Transparency & Control:** Comprehensive visibility into AI interactions via a dedicated inspector and detailed session logging.
- **Strict Money Safety:** Prevents accidental costs through explicit cloud selection, per-request caps, and budget enforcement.
- **Privacy & Persistence:** A local-first architecture where data is stored directly on the user's file system and UI calls are restricted to localhost.

## Key Features
- **Visual Interface:** Leverages the existing "Forest Terminal" layout without redesign.
- **Session Management & Inspector:** Detailed history of sessions with the ability to inspect raw request/response payloads.
- **Provider Support:**
    - **Local Models:** Primary execution via a local gateway (Ollama optional).
    - **Cloud:** Google Gemini only.
- **Financial & Data Safety:**
    - **Local Default:** System defaults to local models; Cloud requires explicit selection + confirmation.
    - **No Auto-Fallback:** Never silently switches to cloud providers.
    - **No Background Cloud:** No auto-title, auto-summary, memory, indexing, or retries consuming cloud resources unless explicitly enabled.
    - **Key Security:** API keys stored only in the local gateway, never in the frontend.
    - **Cost Logging:** Every cloud call logged with token usage and estimated/actual cost.
    - **Limits:** Enforced per-request caps and daily/weekly/monthly budget ceilings.
- **Privacy Enforcement:**
    - **Routing:** UI strictly communicates only with `localhost`/`127.0.0.1`. The gateway is the only component authorized to communicate with Gemini/Cloud APIs.
    - **No Telemetry:** No remote endpoints or background uploads.
    - **Cloud Sync:** OFF by default; only enabled if explicitly configured later.
- **Local File System Storage:** Data persistence managed via a local sidecar to store sessions as editable Markdown or JSON files.

## Phasing & Scope
- **Phase 1 (Current):** Wire basic UI interactions and state (panels, sessions list, model/provider selector, message rendering). Logs and inspector populate from mock data. No real model calls until gateway contract is established.
- **Phase 2:** Implementation of full keyboard-first command palette and advanced shortcuts.
    - **Cloud Action Safety:** No keyboard shortcut or command palette action may initiate a cloud request without an explicit user confirmation ("Run in Cloud"). Shortcuts operate on local state or local models by default; no background cloud calls.

## Visual Identity (Amber Synthwave Noir)
The application adheres to a strict "Amber Synthwave Noir" aesthetic, utilizing a specific palette while maintaining the existing "Forest Terminal" structure:
- **Surfaces:** Dark Obsidian (#0A0C10) and Deep Steel (#141824).
- **Secondary/Borders:** #404656.
- **Focus/Selection:** Electric Blue (#2F80ED).
- **Warnings/Destructive:** Ember Orange-Red (#E05B3C).
- **Typography:** Paper White (#F2F4F8).
- **Style:** Minimal glow, no scanline effects, and strictly enforced theme tokens.
