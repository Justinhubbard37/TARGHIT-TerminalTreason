﻿# Product Guidelines: Neon Void Terminal

## Voice & Tone
- **Technical & Precise:** All system messages, logs, and labels should be direct, objective, and information-dense. Avoid conversational filler or personality; focus on providing actionable data to the user.
- **System-First:** Communication should reflect the "terminal" nature of the app—think system diagnostics, compiler output, or low-level logs.

## Visual Identity & Component Styling
The "Amber Synthwave Noir" aesthetic is enforced through strict adherence to the defined palette and the existing "Forest Terminal" layout.

### Color Palette Enforcement
- **Main Background:** #0A0C10 (Dark Obsidian)
- **Component Surfaces:** #141824 (Deep Steel)
- **Borders & Dividers:** #404656
- **Primary Action/Focus:** #2F80ED (Electric Blue)
- **Destructive/Warning:** #E05B3C (Ember Orange-Red)
- **Primary Text:** #F2F4F8 (Paper White)

### UI Principles
- **No Layout Shifts:** The existing "Forest Terminal" grid and layout structure must remain untouched. All visual changes are applied via CSS variables or direct styling within this framework.
- **Strict Token Usage:** Every UI element must map to one of the six defined color tokens. No off-palette colors are permitted.
- **Effects:**
    - **Glow:** Very subtle glow effects are allowed using only opacity adjustments of existing tokens (e.g., #2F80ED at 20% opacity). No new hex values are permitted.
    - **Gradients:** Gradients are only permitted for "faded edges" or overlays and must use opacity variations of existing tokens.
- **No CRT Effects:** No scanlines or heavy retro distortion.

## User Interaction & Feedback
- **High-Contrast Focus:** Use Electric Blue (#2F80ED) for all active states, focus rings, and selections to provide immediate visual feedback in the dark environment.
- **Cloud Confirmation:** Any action that initiates a cloud request (Gemini) MUST be preceded by a high-contrast confirmation modal. Users can confirm via a visible "Confirm" button OR by pressing `Shift+Enter`.
- **Persistent Status:** The status bar must clearly indicate the current provider (Local vs. Cloud) and any relevant cost/budget information.
- **Non-Intrusive Notifications:** Local actions (saving, loading) should use brief toast notifications that don't interrupt the user's flow.

## Architectural & Behavioral Guidelines
- **Hard-Lock Routing:** The UI is strictly prohibited from making direct network calls to any external service. All UI requests MUST be routed to `localhost` or `127.0.0.1`. Only the local gateway is authorized to communicate with Cloud APIs (Gemini).
- **No Background Cloud Activity:** By default, no background features that consume cloud resources (auto-title, auto-summary, memory, indexing, retries) are allowed. These features can only run if explicitly enabled by the user.

## Data Presentation
- **Inspector Styling:** Use the defined palette for syntax highlighting in the AI session inspector. Use Electric Blue (#2F80ED) for JSON keys and Paper White (#F2F4F8) for values.
- **Unobtrusive Overlays:** Custom scrollbars and faded list edges must blend seamlessly into the #0A0C10 / #141824 backgrounds to maintain the noir feel.

