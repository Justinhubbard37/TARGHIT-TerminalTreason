Change requests for product guide (product.md):

- Personal-use-first: primary user is me; may later be released, but not designed as a cloud-first SaaS.
- Preserve existing UI: keep the current “Forest Terminal” layout and structure; do not redesign or change layout during initial development.
- Providers (v1): support Local models + Google Gemini only. Remove OpenAI references. Describe local as “local runner via local gateway” (Ollama optional, not required).
- Local-first + cost safety (must be explicit):
  - Default provider = Local for all new sessions.
  - Cloud calls require explicit provider/model selection AND a confirm step (“Run in Cloud” / confirm-before-cloud toggle).
  - No silent fallback from Local to Cloud; if Local fails, show an error.
  - No background Cloud calls (no auto-title, auto-summary, memory, indexing, retries) unless explicitly enabled by the user.
  - Cloud API keys never stored in the browser; keys live only in the local gateway.
  - Log every Cloud call (provider, model, timestamp, input/output tokens, estimated/actual cost when available).
  - Enforce per-request caps (max output tokens, max context/prompt size) and daily/weekly/monthly budget ceilings at the gateway.
- Privacy/security hard rules:
  - UI may only call localhost/127.0.0.1 endpoints by default.
  - No telemetry, no remote endpoints, no background uploads.
  - Cloud sync is OFF unless explicitly enabled later.
- Data persistence (v1): local gateway stores sessions/logs on the user’s machine as editable JSON/Markdown (implementation detail may be files now, SQLite later; UI stays the same).
- Scope for Phase 1: wire basic UI interactions and state only (panels, sessions list, model/provider selector state, send message -> renders in UI, logs/inspector populate from mock data). No real model calls until the gateway contract is in place.
- Visual identity: enforce Amber Synthwave Noir tokens ONLY (#0A0C10 #141824 #404656 #2F80ED #E05B3C #F2F4F8), minimal glow, no scanlines.

---

Additional fixes to apply:
- Add explicit Phase 1 scope: wire basic UI interactions + state + mock gateway responses; no real model calls until gateway contract exists.
- Reword command palette/keyboard-first as “Phase 2” (keep shortcuts now, command palette later).
- Clarify routing: UI never calls cloud APIs; UI only calls localhost; gateway is the only component that talks to Gemini/cloud.
- Expand “No Background Cloud” examples: no auto-title, auto-summary, memory, indexing, retries unless explicitly enabled.
- Add: Cloud sync OFF unless explicitly enabled later.
- Cost logging: record actual cost when available; otherwise estimate.
