﻿# Tech Stack: Neon Void Terminal

## Core Frontend
- **Framework:** React 19 (TypeScript)
- **Build Tool:** Vite
- **Styling:** Standard CSS (Global styles via `index.css`, enforcing Amber Synthwave Noir tokens)
- **Icons:** Lucide React

## Local Architecture
- **Routing:** Hard-locked to `localhost` / `127.0.0.1`. The UI is prohibited from calling Cloud APIs directly.
- **Local Gateway:** A required localhost-only component that serves as the exclusive bridge to AI providers.
    - **Provider Orchestration:** Handles routing between local and cloud models.
    - **Key Security:** Stores API keys securely; keys never enter the browser context.
    - **Safety & Enforcement:** Manages cost logging, budget ceilings, and prevents background cloud activity.

## AI Providers
- **Local Models:** Local runner behind the gateway (Ollama optional; runner-agnostic).
- **Cloud Models:** Google Gemini only (routed exclusively through the gateway).

## Data & Persistence
- **Storage Strategy:** Local file-based storage (sessions/logs stored as JSON/Markdown) managed by the gateway.
- **Evolution:** Implementation may migrate to SQLite in the future, but the UI/Gateway contract will remain stable.

## Development Constraints
- **State Management:** Standard React state (Hooks/Context) for managing session selection and UI panels.
- **Dependencies:** Adhere strictly to existing project dependencies; do not introduce new styling frameworks.
