/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './index.html',
    './App.tsx',
    './index.tsx',
    './src/**/*.{ts,tsx,js,jsx}',
    './components/**/*.{ts,tsx,js,jsx}',
  ],
  theme: {
    extend: {
      colors: {
        // Aliases used by the UI
        obsidian: '#0A0C10',
        void: '#0A0C10',
        panel: '#141824',
        border: '#404656',
        neon: '#2F80ED',
        danger: '#E05B3C',
        ember: '#E05B3C',
        platinum: '#F2F4F8',
      },
      fontFamily: {
        mono: [
          'ui-monospace',
          'SFMono-Regular',
          'Menlo',
          'Monaco',
          'Consolas',
          'Liberation Mono',
          'Courier New',
          'monospace',
        ],
        sans: [
          'system-ui',
          '-apple-system',
          'BlinkMacSystemFont',
          'Segoe UI',
          'Roboto',
          'Helvetica Neue',
          'Arial',
          'sans-serif',
        ],
      },
      boxShadow: {
        neon: '0 0 10px rgba(47, 128, 237, 0.3), 0 0 20px rgba(47, 128, 237, 0.1)',
        'neon-sm': '0 0 5px rgba(47, 128, 237, 0.4)',
      },
    },
  },
  plugins: [],
};
