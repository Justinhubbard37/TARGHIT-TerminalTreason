import sys
import os
import json
import base64
import ctypes
from typing import Optional, Dict

class DATA_BLOB(ctypes.Structure):
    _fields_ = [("cbData", ctypes.c_ulong), ("pbData", ctypes.POINTER(ctypes.c_byte))]

class KeyStore:
    def __init__(self, filepath="secrets.dat"):
        self.filepath = filepath
        self._cache: Dict[str, str] = {}
        self._loaded = False

    def _get_dpapi(self):
        if sys.platform == "win32":
            return ctypes.windll.crypt32
        return None

    def _encrypt(self, plaintext: str) -> str:
        crypt = self._get_dpapi()
        if not crypt:
            # Fallback for non-windows: just base64 (dev only)
            return base64.b64encode(plaintext.encode("utf-8")).decode("utf-8")

        # Prepare input blob
        data_in = DATA_BLOB()
        data_in.cbData = len(plaintext)
        data_in.pbData = ctypes.cast(ctypes.create_string_buffer(plaintext.encode("utf-8")), ctypes.POINTER(ctypes.c_byte))
        
        data_out = DATA_BLOB()
        
        # 1. Encrypt
        if crypt.CryptProtectData(ctypes.byref(data_in), None, None, None, None, 0, ctypes.byref(data_out)):
            try:
                # 2. Copy data
                raw = ctypes.string_at(data_out.pbData, data_out.cbData)
                
                # 3. Securely free memory using LocalFree from kernel32
                kernel32 = ctypes.windll.kernel32
                # Validates argtypes/restype essentially
                kernel32.LocalFree.argtypes = [ctypes.c_void_p]
                kernel32.LocalFree.restype = ctypes.c_void_p
                
                kernel32.LocalFree(ctypes.cast(data_out.pbData, ctypes.c_void_p))
                
                return base64.b64encode(raw).decode("utf-8")
            except Exception as e:
                # Even if copy/free fails, we must try to survive or raise specific error
                raise Exception(f"Encryption memory operation failed: {e}")
        else:
            raise Exception(f"DPAPI Encryption failed. Error: {ctypes.GetLastError()}")

    def _decrypt(self, b64data: str) -> str:
        crypt = self._get_dpapi()
        raw = base64.b64decode(b64data)
        if not crypt:
            return raw.decode("utf-8")

        data_in = DATA_BLOB()
        data_in.cbData = len(raw)
        data_in.pbData = ctypes.cast(ctypes.create_string_buffer(raw), ctypes.POINTER(ctypes.c_byte))
        
        data_out = DATA_BLOB()
        
        if crypt.CryptUnprotectData(ctypes.byref(data_in), None, None, None, None, 0, ctypes.byref(data_out)):
            try:
                plaintext = ctypes.string_at(data_out.pbData, data_out.cbData).decode("utf-8")
                
                # Securely free memory using LocalFree from kernel32
                kernel32 = ctypes.windll.kernel32
                kernel32.LocalFree.argtypes = [ctypes.c_void_p]
                kernel32.LocalFree.restype = ctypes.c_void_p
                
                kernel32.LocalFree(ctypes.cast(data_out.pbData, ctypes.c_void_p))
                
                return plaintext
            except Exception as e:
                raise Exception(f"Decryption memory operation failed: {e}")
        else:
            raise Exception(f"DPAPI Decryption failed. Error: {ctypes.GetLastError()}")

    def save_key(self, provider: str, key: str):
        self._load()
        self._cache[provider] = key
        # Persist
        try:
            encrypted = {k: self._encrypt(v) for k, v in self._cache.items()}
            with open(self.filepath, "w", encoding="utf-8") as f:
                json.dump(encrypted, f)
        except Exception as e:
            # log handled by caller or we can't log here easily without importing logger
            raise

    def get_key(self, provider: str) -> Optional[str]:
        self._load()
        return self._cache.get(provider)

    def _load(self):
        if self._loaded:
            return
        if os.path.exists(self.filepath):
            try:
                with open(self.filepath, "r", encoding="utf-8") as f:
                    encrypted = json.load(f)
                self._cache = {k: self._decrypt(v) for k, v in encrypted.items()}
            except Exception as e:
                # Log to stderr or just ignore? The main app logs errors.
                # Since we don't have logger here, we suppress or print
                print(f"Failed to load keys: {e}", file=sys.stderr)
        self._loaded = True

keystore = KeyStore()
