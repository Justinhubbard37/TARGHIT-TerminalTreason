import sys
import os
import json
import time
import base64
import ctypes
from typing import Dict, Any, List, Optional, Literal
from datetime import datetime, timezone

from fastapi import FastAPI, HTTPException, Request, Response, Depends, Body, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
import uvicorn
import httpx
import uuid

# Local imports
from .secure_store import keystore

# -----------------------------
# Configuration
# -----------------------------
HTTP_TIMEOUT_S = 30
GATEWAY_VERSION = "0.2.1"

# Environment Variables
ENV_GEMINI_KEY = os.getenv("TT_CLOUD_GEMINI_KEY", "")
GATEWAY_KEY = os.getenv("TT_GATEWAY_KEY", "sk-gateway-dev-key") # Default for dev
DEFAULT_LOCAL_BASE_URL = os.getenv("TT_LOCAL_BASE_URL", "http://127.0.0.1:1234")

# Internal Constants
LOCAL_MAIN_ID = "local-main"
CLOUD_GEMINI_ID = "gemini"

# Gemini Config
GEMINI_BASE_URL = "https://generativelanguage.googleapis.com/v1beta"

# Security: Allowed Origins (Localhost only)
ALLOWED_ORIGINS = [
    "http://localhost:5173",
    "http://127.0.0.1:5173",
    "http://localhost:3000",
    "http://127.0.0.1:3000",
]

app = FastAPI(title="TerminalTreason Gateway")

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# -----------------------------
# Secure Key Storage (DPAPI)
# -----------------------------
# Moved to secure_store.py



# -----------------------------
# Schemas
# -----------------------------
class ProviderStatus(BaseModel):
    id: str
    type: Literal["local", "cloud"]
    name: str
    status: Literal["ok", "degraded", "disabled", "error"]
    latencyMs: int = 0
    lastError: Optional[str] = None


class ModelDescriptor(BaseModel):
    id: str
    displayName: str
    providerId: str
    capabilities: List[str] = Field(default_factory=lambda: ["chat"])
    contextWindow: Optional[int] = None
    recommended: Optional[Dict[str, Any]] = None


class ChatMessage(BaseModel):
    role: Literal["system", "user", "assistant", "tool"]
    content: str


class ChatParams(BaseModel):
    temperature: Optional[float] = None
    topP: Optional[float] = None
    maxTokens: Optional[int] = None
    stop: Optional[List[str]] = None


class ChatMetadata(BaseModel):
    sessionId: Optional[str] = None
    messageId: Optional[str] = None


class ChatCompletionRequest(BaseModel):
    model: str
    messages: List[ChatMessage]
    providerId: Optional[str] = None
    params: Optional[ChatParams] = None
    metadata: Optional[ChatMetadata] = None


class KeyRequest(BaseModel):
    apiKey: str


class ChatCompletionOutput(BaseModel):
    role: str
    content: str


class ChatUsage(BaseModel):
    inputTokens: int = 0
    outputTokens: int = 0


class ChatTiming(BaseModel):
    latencyMs: int = 0


class ChatCompletionResponse(BaseModel):
    id: str
    providerId: str
    model: str
    output: ChatCompletionOutput
    usage: ChatUsage
    timing: ChatTiming



# -----------------------------
# Helpers
# -----------------------------
def log(level: str, msg: str, **kwargs):
    # JSON structured logging
    entry = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "level": level.upper(),
        "message": msg,
        **kwargs
    }
    print(json.dumps(entry))


def iso_now():
    return datetime.now(timezone.utc).isoformat()


async def verify_api_key(request: Request):
    auth_header = request.headers.get("Authorization")
    if not auth_header or not auth_header.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing or invalid Bearer token")
    token = auth_header.split(" ")[1]
    if token != GATEWAY_KEY:
        log("warn", "Authentication failed", ip=request.client.host)
        raise HTTPException(status_code=403, detail="Forbidden")
    return token


async def _probe_openai_models(base_url: str) -> Dict[str, Any]:
    """Try GET {base_url}/v1/models and return parsed JSON."""
    url = base_url.rstrip("/") + "/v1/models"
    async with httpx.AsyncClient(timeout=HTTP_TIMEOUT_S) as client:
        r = await client.get(url)
        r.raise_for_status()
        return r.json()


def _coerce_model_ids(payload: Any) -> List[str]:
    """Best-effort extraction of model ids from common OpenAI-compatible responses."""
    if not isinstance(payload, dict):
        return []

    # OpenAI format: {"object":"list","data":[{"id":"..."}, ...]}
    data = payload.get("data")
    if isinstance(data, list):
        out: List[str] = []
        for item in data:
            if isinstance(item, dict) and isinstance(item.get("id"), str):
                out.append(item["id"])
        return out

    # Some servers return {"models":[{"id":"..."}, ...]}
    models = payload.get("models")
    if isinstance(models, list):
        out = []
        for item in models:
            if isinstance(item, dict) and isinstance(item.get("id"), str):
                out.append(item["id"])
        return out

    return []


def _sse_event(event: str, data_obj: Dict[str, Any]) -> bytes:
    # SSE format: event + data + blank line
    return (f"event: {event}\n" f"data: {json_dumps(data_obj)}\n\n").encode("utf-8")


def json_dumps(obj: Any) -> str:
    import json

    return json.dumps(obj, ensure_ascii=False)


# -----------------------------
# Endpoints (contract)
# -----------------------------
@app.get("/")
async def root():
    return await health()


@app.get("/v1/health")
async def health() -> Dict[str, Any]:
    providers: List[ProviderStatus] = []

    # Local-main probe (best-effort)
    t0 = time.time()
    try:
        await _probe_openai_models(DEFAULT_LOCAL_BASE_URL)
        providers.append(
            ProviderStatus(
                id=LOCAL_MAIN_ID,
                type="local",
                name="Local Engine (llama.cpp)",
                status="ok",
                latencyMs=int((time.time() - t0) * 1000),
                lastError=None,
            )
        )
    except Exception as e:
        providers.append(
            ProviderStatus(
                id=LOCAL_MAIN_ID,
                type="local",
                name="Local Engine (llama.cpp)",
                status="degraded",
                latencyMs=int((time.time() - t0) * 1000),
                lastError=str(e),
            )
        )

    # Cloud/Gemini status
    # Check if key is stored
    has_key = keystore.get_key(CLOUD_GEMINI_ID) or ENV_GEMINI_KEY
    if has_key:
        providers.append(
            ProviderStatus(
                id=CLOUD_GEMINI_ID,
                type="cloud",
                name="Gemini",
                status="ok",
                latencyMs=0,
                lastError=None,
            )
        )
    else:
        providers.append(
            ProviderStatus(
                id=CLOUD_GEMINI_ID,
                type="cloud",
                name="Gemini",
                status="disabled",
                latencyMs=0,
                lastError="Missing Gemini Key (Secure Store)",
            )
        )

    return {
        "status": "ok",
        "gatewayVersion": GATEWAY_VERSION,
        "time": iso_now(),
        "providers": [p.model_dump() for p in providers],
    }


@app.post("/v1/keys/gemini", dependencies=[Depends(verify_api_key)])
async def store_gemini_key(payload: KeyRequest = Body(...)):
    if not payload.apiKey:
        raise HTTPException(status_code=400, detail="apiKey required")
    try:
        keystore.save_key(CLOUD_GEMINI_ID, payload.apiKey)
        log("info", "Gemini key updated in secure store")
        return {"ok": True}
    except Exception as e:
        log("error", f"Failed to save key: {e}")
        raise HTTPException(status_code=500, detail="Failed to save key to secure store")


@app.get("/v1/models", dependencies=[Depends(verify_api_key)])
async def list_models(
    providerId: Optional[str] = Query(default=None),
    capability: Optional[str] = Query(default=None),
) -> Dict[str, Any]:
    models: List[ModelDescriptor] = []

    # Local engine models
    if providerId in (None, "", LOCAL_MAIN_ID):
        try:
            payload = await _probe_openai_models(DEFAULT_LOCAL_BASE_URL)
            ids = _coerce_model_ids(payload)
            for mid in ids:
                models.append(
                    ModelDescriptor(
                        id=mid,
                        displayName=mid,
                        providerId=LOCAL_MAIN_ID,
                        capabilities=["chat"],
                        contextWindow=None,
                        recommended={"temperature": 0.2, "maxTokens": 1024},
                    )
                )
        except Exception as e:
            log("warn", f"local models probe failed: {e}", providerId=LOCAL_MAIN_ID)

    # Cloud/Gemini models (static discovery placeholder)
    if providerId in (None, "", CLOUD_GEMINI_ID):
        # Only if we have a key
        if keystore.get_key(CLOUD_GEMINI_ID) or ENV_GEMINI_KEY:
             models.append(ModelDescriptor(
                 id="gemini-2.0-flash-exp",
                 displayName="Gemini 2.0 Flash (Experimental)",
                 providerId=CLOUD_GEMINI_ID,
                 contextWindow=1048576,
             ))
             models.append(ModelDescriptor(
                 id="gemini-1.5-pro",
                 displayName="Gemini 1.5 Pro",
                 providerId=CLOUD_GEMINI_ID,
                 contextWindow=2097152,
             ))
             models.append(ModelDescriptor(
                 id="gemini-1.5-flash",
                 displayName="Gemini 1.5 Flash",
                 providerId=CLOUD_GEMINI_ID,
                 contextWindow=1048576,
             ))

    return {
        "models": [m.model_dump() for m in models],
        "count": len(models),
    }


@app.post("/v1/providers/test", dependencies=[Depends(verify_api_key)])
async def test_provider(
    payload: Dict[str, Any] = Body(...),
) -> Dict[str, Any]:
    # Backward compatibility: flatten { "provider": {...} } -> {...}
    prov_data = payload.get("provider", payload)
    
    prov_type = prov_data.get("type")
    prov_id = prov_data.get("id")
    prov_api_key = prov_data.get("apiKey")
    
    # Local test
    if prov_type == "local":
        base = DEFAULT_LOCAL_BASE_URL
        if not base:
            return {"status": "error", "latencyMs": 0, "details": "missing baseUrl"}

        t0 = time.time()
        try:
            await _probe_openai_models(base)
            return {"status": "ok", "latencyMs": int((time.time() - t0) * 1000), "details": "reachable"}
        except Exception as e:
            return {"status": "error", "latencyMs": int((time.time() - t0) * 1000), "details": str(e)}

    # Cloud test
    if prov_type == "cloud":
        # Look up key from payload OR secure store OR env
        key = prov_api_key or keystore.get_key(CLOUD_GEMINI_ID) or ENV_GEMINI_KEY
        if not key:
            return {"status": "error", "latencyMs": 0, "details": "missing key (secure store)"}
        
        # Simple list models probe to verify key.
        t0 = time.time()
        url = f"{GEMINI_BASE_URL}/models?key={key}"
        async with httpx.AsyncClient(timeout=HTTP_TIMEOUT_S) as client:
            try:
                r = await client.get(url)
                if r.status_code == 200:
                    return {"status": "ok", "latencyMs": int((time.time() - t0) * 1000), "details": "reachable"}
                return {"status": "error", "latencyMs": int((time.time() - t0) * 1000), "details": f"HTTP {r.status_code}"}
            except Exception as e:
                return {"status": "error", "latencyMs": int((time.time() - t0) * 1000), "details": str(e)}

    return {"status": "error", "latencyMs": 0, "details": "unknown provider type"}


@app.post("/v1/chat/completions", dependencies=[Depends(verify_api_key)])
async def chat_completions(req: ChatCompletionRequest = Body(...)) -> ChatCompletionResponse:
    t0 = time.time()
    
    # Internal helper to get raw text
    async def _get_text() -> str:
        # If providerId is local-main, proxy to llama.cpp
        if not req.providerId or req.providerId == LOCAL_MAIN_ID:
            url = f"{DEFAULT_LOCAL_BASE_URL}/v1/chat/completions"
            body = {
                "model": req.model,
                "messages": [{"role": m.role, "content": m.content} for m in req.messages],
                "temperature": (req.params.temperature if req.params else None),
                "top_p": (req.params.topP if req.params else None),
                "max_tokens": (req.params.maxTokens if req.params else None),
                "stop": (req.params.stop if req.params else None),
                "stream": False,
            }

            async with httpx.AsyncClient(timeout=HTTP_TIMEOUT_S) as client:
                r = await client.post(url, json=body)
                r.raise_for_status()
                data = r.json()

            try:
                return data["choices"][0]["message"]["content"]
            except Exception:
                return "(local engine responded, but content could not be parsed)"

        if req.providerId == CLOUD_GEMINI_ID:
            # Check secure store then env
            key = keystore.get_key(CLOUD_GEMINI_ID) or ENV_GEMINI_KEY
            if not key:
                 # We return error text as content so UI shows it
                 return "Error: Gateway has no stored Gemini key. Please configure in settings."

            # Mapping: https://ai.google.dev/api/rest/v1beta/models/generateContent
            url = f"{GEMINI_BASE_URL}/models/{req.model}:generateContent?key={key}"

            # Convert messages to Gemini format
            contents = []
            for m in req.messages:
                role = "user"
                if m.role == "assistant":
                    role = "model"
                elif m.role == "system":
                    role = "user"

                contents.append({
                    "role": role,
                    "parts": [{"text": m.content}]
                })

            body = {
                "contents": contents,
                "generationConfig": {
                    "temperature": req.params.temperature if req.params else 0.7,
                    "maxOutputTokens": req.params.maxTokens if req.params else 1024,
                }
            }

            async with httpx.AsyncClient(timeout=HTTP_TIMEOUT_S * 2) as client:
                r = await client.post(url, json=body)
                if r.status_code != 200:
                    error_body = r.text
                    try:
                        error_json = r.json()
                        if "error" in error_json:
                            return f"Gemini Error: {error_json['error'].get('message', error_body)}"
                    except:
                        pass
                    return f"Gemini HTTP {r.status_code}: {error_body}"
                
                data = r.json()

            try:
                return data["candidates"][0]["content"]["parts"][0]["text"]
            except Exception as e:
                return f"Failed to parse Gemini response: {e} \nRaw: {data}"

        return f"Unknown provider: {req.providerId}"

    # Execution
    try:
        content = await _get_text()
    except Exception as e:
        content = f"Gateway Internal Error: {str(e)}"

    latency = int((time.time() - t0) * 1000)
    
    return ChatCompletionResponse(
        id=str(uuid.uuid4()),
        providerId=req.providerId or LOCAL_MAIN_ID,
        model=req.model,
        output=ChatCompletionOutput(role="assistant", content=content),
        usage=ChatUsage(inputTokens=0, outputTokens=0),
        timing=ChatTiming(latencyMs=latency)
    )

if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=8787)
