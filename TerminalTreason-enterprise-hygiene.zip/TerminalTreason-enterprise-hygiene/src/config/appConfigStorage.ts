import { getDefaultAppConfig, normalizeAppConfig, type AppConfig } from './appConfig';

const DB_NAME = 'terminaltreason';
const LEGACY_DB_NAMES = ['forestterm'];

const DB_VERSION = 1;
const STORE_NAME = 'appConfig';
const SINGLETON_ID = 'singleton';

type StoredRecordV1 = {
  id: string;
  config: unknown;
  savedAt: number;
};

export type LoadAppConfigResult = {
  config: AppConfig;
  errors: string[];
  migratedFromDb?: string;
};

export async function loadAppConfig(): Promise<LoadAppConfigResult> {
  const errors: string[] = [];

  // 1) Try current DB first
  const current = await tryLoadFromDb(DB_NAME, errors);
  if (current.found) {
    const normalized = normalizeAppConfig(current.raw);
    return { config: normalized.config, errors: [...errors, ...normalized.errors] };
  }

  // 2) Try legacy DBs (one-time import/migration)
  for (const legacyName of LEGACY_DB_NAMES) {
    const legacy = await tryLoadFromDb(legacyName, errors);
    if (!legacy.found) continue;

    const normalized = normalizeAppConfig(legacy.raw);
    const mergedErrors = [...errors, ...normalized.errors, `Migrated config from legacy DB "${legacyName}" -> "${DB_NAME}".`];

    // Best-effort: save into current DB
    await safeSaveToDb(DB_NAME, normalized.config, mergedErrors);

    // Best-effort: remove legacy DB after migration (optional behavior)
    await safeDeleteDb(legacyName, mergedErrors);

    return { config: normalized.config, errors: mergedErrors, migratedFromDb: legacyName };
  }

  // 3) Nothing found anywhere: defaults
  return { config: getDefaultAppConfig(), errors };
}

export async function saveAppConfig(config: AppConfig): Promise<{ ok: boolean; error?: string }> {
  try {
    await writeToDb(DB_NAME, config);
    return { ok: true };
  } catch (e: any) {
    return { ok: false, error: e?.message ? String(e.message) : String(e) };
  }
}

export async function clearAppConfig(): Promise<{ ok: boolean; error?: string }> {
  try {
    const db = await openDb(DB_NAME);
    await runTx(db, 'readwrite', (store) => store.delete(SINGLETON_ID));
    db.close();
    return { ok: true };
  } catch (e: any) {
    return { ok: false, error: e?.message ? String(e.message) : String(e) };
  }
}


// Deletes the entire IndexedDB database(s) used by this app (current + legacy).
// Use for "Reset" actions where you want a clean slate.
export async function wipeAllAppData(): Promise<{ ok: boolean; error?: string }> {
  try {
    if (!isIndexedDbUsable()) return { ok: false, error: 'IndexedDB is not available.' };

    // Delete current DB
    await deleteDb(DB_NAME);

    // Best-effort delete of legacy DBs (non-fatal if blocked)
    for (const legacy of LEGACY_DB_NAMES) {
      await deleteDb(legacy);
    }

    return { ok: true };
  } catch (e: any) {
    return { ok: false, error: e?.message ? String(e.message) : String(e) };
  }
}

export function isIndexedDbUsable(): boolean {
  try {
    return typeof indexedDB !== 'undefined';
  } catch {
    return false;
  }
}

/* ------------------------------ internals ------------------------------ */

async function tryLoadFromDb(
  name: string,
  errors: string[]
): Promise<{ found: boolean; raw: unknown | null }> {
  if (!isIndexedDbUsable()) {
    errors.push('IndexedDB is not available in this environment.');
    return { found: false, raw: null };
  }

  try {
    const db = await openDb(name);
    const raw = await readFromDb(db);
    db.close();

    if (raw == null) return { found: false, raw: null };
    return { found: true, raw };
  } catch (e: any) {
    errors.push(`Failed to read IndexedDB "${name}": ${e?.message ? String(e.message) : String(e)}`);
    return { found: false, raw: null };
  }
}

async function readFromDb(db: IDBDatabase): Promise<unknown | null> {
  // If the store doesn't exist, treat as empty.
  if (!db.objectStoreNames.contains(STORE_NAME)) return null;

  const value = await runTx(db, 'readonly', (store) => store.get(SINGLETON_ID));
  if (value == null) return null;

  // Support both shapes:
  // - StoredRecordV1 { id, config, savedAt }
  // - Direct config stored at key "singleton"
  if (isRecord(value) && 'config' in value) {
    const rec = value as StoredRecordV1;
    return unwrapMaybe(rec.config);
  }
  return unwrapMaybe(value);
}

async function writeToDb(dbName: string, config: AppConfig): Promise<void> {
  if (!isIndexedDbUsable()) throw new Error('IndexedDB is not available.');

  const db = await openDb(dbName);

  const record: StoredRecordV1 = {
    id: SINGLETON_ID,
    config,
    savedAt: Date.now(),
  };

  await runTx(db, 'readwrite', (store) => store.put(record));
  db.close();
}

async function safeSaveToDb(dbName: string, config: AppConfig, errors: string[]): Promise<void> {
  try {
    await writeToDb(dbName, config);
  } catch (e: any) {
    errors.push(`Failed to save migrated config into "${dbName}": ${e?.message ? String(e.message) : String(e)}`);
  }
}

async function safeDeleteDb(dbName: string, errors: string[]): Promise<void> {
  try {
    await deleteDb(dbName);
  } catch (e: any) {
    // Optional cleanup only; do not treat as fatal.
    errors.push(`Could not delete legacy DB "${dbName}" (non-fatal): ${e?.message ? String(e.message) : String(e)}`);
  }
}

function unwrapMaybe(value: unknown): unknown {
  // Support older wrapper keys if they ever existed
  if (isRecord(value) && 'data' in value) return (value as any).data;
  if (isRecord(value) && 'value' in value) return (value as any).value;
  return value;
}

async function openDb(name: string): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(name, DB_VERSION);

    req.onupgradeneeded = () => {
      const db = req.result;

      // Create the store if missing
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: 'id' });
      }
    };

    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error ?? new Error('Failed to open IndexedDB'));
  });
}

async function runTx<T>(
  db: IDBDatabase,
  mode: IDBTransactionMode,
  fn: (store: IDBObjectStore) => IDBRequest<T>
): Promise<T> {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, mode);
    const store = tx.objectStore(STORE_NAME);

    const req = fn(store);

    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error ?? new Error('IndexedDB request failed'));

    tx.onabort = () => reject(tx.error ?? new Error('IndexedDB transaction aborted'));
  });
}

async function deleteDb(name: string): Promise<void> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.deleteDatabase(name);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error ?? new Error('Failed to delete IndexedDB'));
    req.onblocked = () => resolve(); // If blocked, treat as non-fatal for cleanup.
  });
}

function isRecord(v: unknown): v is Record<string, unknown> {
  return typeof v === 'object' && v !== null && !Array.isArray(v);
}
