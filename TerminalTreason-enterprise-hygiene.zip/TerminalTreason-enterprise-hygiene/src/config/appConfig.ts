import type { Message, Session } from '../../types';

/**
 * Current schema version for application configuration.
 */
export const APP_CONFIG_VERSION = 1 as const;
/**
 * Default developer key for the local gateway.
 * Used for simple auth in local-first apps.
 */
export const DEFAULT_GATEWAY_KEY = 'terminal-treason-dev-key';

/**
 * Supported AI provider types (local vs cloud).
 */
export type ProviderKind = 'local' | 'cloud';
export type ViewMode = 'chat' | 'settings';
export type TooltipMode = 'smart' | 'centered';

/**
 * Base URLs for local AI providers (Ollama, LM Studio).
 */
export interface ProviderEndpoints {
  ollamaBaseUrl: string;   // e.g. http://127.0.0.1:11434
  lmStudioBaseUrl: string; // e.g. http://127.0.0.1:1234
}

/**
 * Structure for storing API keys (raw).
 * Note: These fields should always be masked in the UI and never logged.
 */
export interface CloudApiKeys {
  // Stored as raw strings in config, but MUST be masked in UI and NEVER logged.
  // Keep fields explicit for clarity and migrations.
  gemini?: string;
  openai?: string;
  anthropic?: string;

  // Future-proofing: if you add new providers later without schema churn.
  extras?: Record<string, string>;
}

/**
 * Internal state shape for the chat sessions.
 */
export interface ChatStateConfig {
  sessions: Session[];
  activeSessionId: string | null;
  messagesBySession: Record<string, Message[]>;
}

/**
 * Main configuration interface persisted to storage.
 */
export interface AppConfig {
  version: number;

  ui: {
    leftCollapsed: boolean;
    rightCollapsed: boolean;
    viewMode: ViewMode;
    tooltipMode: TooltipMode;
  };

  model: {
    provider: ProviderKind;
    modelName: string;
  };

  modelByProvider?: {
    local: string;
    cloud: string;
  };

  providers: {
    endpoints: ProviderEndpoints;
    cloudKeys: CloudApiKeys;
  };

  chats: ChatStateConfig;
}

type UnknownRecord = Record<string, unknown>;

export function getDefaultAppConfig(): AppConfig {
  return {
    version: APP_CONFIG_VERSION,

    ui: {
      leftCollapsed: false,
      rightCollapsed: false,
      viewMode: 'chat',
      tooltipMode: 'smart',
    },

    model: {
      provider: 'local',
      modelName: 'llama3.1:8b',
    },

    providers: {
      endpoints: {
        ollamaBaseUrl: 'http://127.0.0.1:11434',
        lmStudioBaseUrl: 'http://127.0.0.1:1234',
      },
      cloudKeys: {
        gemini: '',
        openai: '',
        anthropic: '',
        extras: {},
      },
    },

    chats: {
      sessions: [],
      activeSessionId: null,
      messagesBySession: {},
    },
  };
}

/**
 * Parse + validate + normalize unknown input into a safe AppConfig.
 * Never throws. Always returns a config; errors indicate what was corrected/dropped.
 */
export function normalizeAppConfig(input: unknown): { config: AppConfig; errors: string[] } {
  const errors: string[] = [];
  const defaults = getDefaultAppConfig();

  if (!isRecord(input)) {
    errors.push('Config root was not an object; using defaults.');
    return { config: defaults, errors };
  }

  const migrated = migrateToCurrentVersion(input, errors);

  const version = toInt(migrated.version, APP_CONFIG_VERSION, errors, 'version');

  const uiRec = asRecord(migrated.ui, errors, 'ui');
  const modelRec = asRecord(migrated.model, errors, 'model');
  const providersRec = asRecord(migrated.providers, errors, 'providers');
  const chatsRec = asRecord(migrated.chats, errors, 'chats');

  const endpointsRec = asRecord((providersRec as UnknownRecord).endpoints, errors, 'providers.endpoints');
  const cloudKeysRec = asRecord((providersRec as UnknownRecord).cloudKeys, errors, 'providers.cloudKeys');

  const config: AppConfig = {
    version,

    ui: {
      leftCollapsed: toBool((uiRec as UnknownRecord).leftCollapsed, defaults.ui.leftCollapsed),
      rightCollapsed: toBool((uiRec as UnknownRecord).rightCollapsed, defaults.ui.rightCollapsed),
      viewMode: toEnum<ViewMode>((uiRec as UnknownRecord).viewMode, ['chat', 'settings'], defaults.ui.viewMode, errors, 'ui.viewMode'),
      tooltipMode: toEnum<TooltipMode>((uiRec as UnknownRecord).tooltipMode, ['smart', 'centered'], defaults.ui.tooltipMode, errors, 'ui.tooltipMode'),
    },

    model: {
      provider: toEnum<ProviderKind>((modelRec as UnknownRecord).provider, ['local', 'cloud'], defaults.model.provider, errors, 'model.provider'),
      modelName: toString((modelRec as UnknownRecord).modelName, defaults.model.modelName),
    },

    providers: {
      endpoints: {
        ollamaBaseUrl: normalizeBaseUrl(toString((endpointsRec as UnknownRecord).ollamaBaseUrl, defaults.providers.endpoints.ollamaBaseUrl)),
        lmStudioBaseUrl: normalizeBaseUrl(toString((endpointsRec as UnknownRecord).lmStudioBaseUrl, defaults.providers.endpoints.lmStudioBaseUrl)),
      },
      cloudKeys: normalizeCloudKeys(cloudKeysRec, errors),
    },

    chats: normalizeChats(chatsRec, errors),
  };

  // Final sanity: if activeSessionId invalid, clamp it.
  const sessionIds = new Set(config.chats.sessions.map(s => s.id));
  if (config.chats.activeSessionId && !sessionIds.has(config.chats.activeSessionId)) {
    errors.push('chats.activeSessionId did not exist in sessions; clamping.');
    config.chats.activeSessionId = config.chats.sessions[0]?.id ?? null;
  }

  // Ensure every session has a bucket.
  for (const s of config.chats.sessions) {
    if (!Array.isArray(config.chats.messagesBySession[s.id])) {
      config.chats.messagesBySession[s.id] = [];
    }
  }

  return { config, errors };
}

/**
 * Redacts secrets for safe debugging. Never log raw AppConfig.
 */
export function redactAppConfigForLogs(config: AppConfig): AppConfig {
  const redacted = deepClone(config);

  const ck = redacted.providers.cloudKeys;
  ck.gemini = ck.gemini ? maskSecret(ck.gemini) : '';
  ck.openai = ck.openai ? maskSecret(ck.openai) : '';
  ck.anthropic = ck.anthropic ? maskSecret(ck.anthropic) : '';
  if (ck.extras) {
    for (const k of Object.keys(ck.extras)) {
      const v = ck.extras[k];
      ck.extras[k] = v ? maskSecret(v) : '';
    }
  }

  return redacted;
}

export function maskSecret(secret: string): string {
  const s = String(secret || '');
  if (!s) return '';
  const trimmed = s.trim();
  if (trimmed.length <= 8) return '••••';
  return `${trimmed.slice(0, 3)}••••${trimmed.slice(-3)}`;
}

/* ------------------------------ migrations ------------------------------ */

function migrateToCurrentVersion(raw: UnknownRecord, errors: string[]): UnknownRecord {
  // v0 -> v1 migrations (supports legacy key names if any exist)
  const v = toInt(raw.version ?? raw.schemaVersion, 0, [], 'version'); // don't double-add errors here
  if (v >= APP_CONFIG_VERSION) return raw;

  const next: UnknownRecord = { ...raw };

  // Example legacy fields support (safe no-ops if absent)
  if (!('version' in next) && ('schemaVersion' in next)) {
    next.version = toInt(next.schemaVersion, APP_CONFIG_VERSION, errors, 'schemaVersion');
  }

  // Ensure core containers exist.
  if (!isRecord(next.ui)) next.ui = {};
  if (!isRecord(next.model)) next.model = {};
  if (!isRecord(next.providers)) next.providers = {};
  if (!isRecord(next.chats)) next.chats = {};

  // Legacy provider endpoints might have lived at providers.ollamaUrl / providers.lmStudioUrl
  const providers = next.providers as UnknownRecord;
  if (!isRecord(providers.endpoints)) providers.endpoints = {};
  const endpoints = providers.endpoints as UnknownRecord;

  if (endpoints.ollamaBaseUrl == null && providers.ollamaUrl != null) endpoints.ollamaBaseUrl = providers.ollamaUrl;
  if (endpoints.lmStudioBaseUrl == null && providers.lmStudioUrl != null) endpoints.lmStudioBaseUrl = providers.lmStudioUrl;

  // Legacy cloud keys might have been providers.keys
  if (!isRecord(providers.cloudKeys)) providers.cloudKeys = {};
  const cloudKeys = providers.cloudKeys as UnknownRecord;
  if (cloudKeys.gemini == null && isRecord(providers.keys) && (providers.keys as UnknownRecord).gemini != null) {
    cloudKeys.gemini = (providers.keys as UnknownRecord).gemini;
  }

  next.version = APP_CONFIG_VERSION;
  return next;
}

/* ------------------------------ normalization helpers ------------------------------ */

function normalizeCloudKeys(input: unknown, errors: string[]): CloudApiKeys {
  if (!isRecord(input)) {
    errors.push('providers.cloudKeys was not an object; defaulting.');
    return { gemini: '', openai: '', anthropic: '', extras: {} };
  }
  const rec = input as UnknownRecord;

  const extrasRaw = rec.extras;
  const extras: Record<string, string> = {};
  if (isRecord(extrasRaw)) {
    for (const [k, v] of Object.entries(extrasRaw)) {
      extras[k] = toString(v, '');
    }
  }

  return {
    gemini: toString(rec.gemini, ''),
    openai: toString(rec.openai, ''),
    anthropic: toString(rec.anthropic, ''),
    extras,
  };
}

function normalizeChats(input: unknown, errors: string[]): ChatStateConfig {
  const defaults = getDefaultAppConfig().chats;

  if (!isRecord(input)) {
    errors.push('chats was not an object; defaulting.');
    return deepClone(defaults);
  }

  const rec = input as UnknownRecord;

  const sessions = normalizeSessions(rec.sessions, errors);
  const sessionIds = new Set(sessions.map(s => s.id));

  const activeSessionId = (rec.activeSessionId == null)
    ? null
    : toString(rec.activeSessionId, null);

  const messagesBySession: Record<string, Message[]> = {};
  const mbs = rec.messagesBySession;

  if (isRecord(mbs)) {
    for (const [sid, msgs] of Object.entries(mbs)) {
      if (!sessionIds.has(sid)) continue; // ignore orphan buckets
      messagesBySession[sid] = normalizeMessages(msgs, errors, `chats.messagesBySession.${sid}`);
    }
  } else if (mbs != null) {
    errors.push('chats.messagesBySession was not an object; defaulting empty.');
  }

  // Ensure buckets for all sessions
  for (const s of sessions) {
    if (!messagesBySession[s.id]) messagesBySession[s.id] = [];
  }

  return {
    sessions,
    activeSessionId: activeSessionId && sessionIds.has(activeSessionId) ? activeSessionId : (sessions[0]?.id ?? null),
    messagesBySession,
  };
}

function normalizeSessions(input: unknown, errors: string[]): Session[] {
  if (!Array.isArray(input)) return [];
  const out: Session[] = [];
  const seen = new Set<string>();

  for (const item of input) {
    if (!isRecord(item)) continue;
    const r = item as UnknownRecord;

    const id = toString(r.id, '');
    if (!id) continue;
    if (seen.has(id)) {
      errors.push(`Duplicate session id "${id}" found; keeping first.`);
      continue;
    }
    seen.add(id);

    out.push({
      id,
      title: toString(r.title, 'New Chat'),
      updatedAt: toString(r.updatedAt, ''),
      updatedAtIso: toString((r as any).updatedAtIso, ''),
    } as Session);
  }

  return out;
}

function normalizeMessages(input: unknown, errors: string[], path: string): Message[] {
  if (!Array.isArray(input)) return [];
  const out: Message[] = [];

  for (const item of input) {
    if (!isRecord(item)) continue;
    const r = item as UnknownRecord;

    const id = toString(r.id, '');
    const role = toString(r.role, '');
    const content = toString(r.content, '');
    const timestamp = toString(r.timestamp, '');
    const timestampIso = toString((r as any).timestampIso, '');

    if (!id || !role || !content) {
      errors.push(`${path}: dropped message missing required fields (id/role/content).`);
      continue;
    }

    const meta = isRecord(r.meta) ? (r.meta as UnknownRecord) : undefined;

    out.push({
      id,
      role: role as any,
      content,
      timestamp,
      timestampIso,
      meta: meta as any,
    } as Message);
  }

  return out;
}

/* ------------------------------ primitives ------------------------------ */

function isRecord(v: unknown): v is UnknownRecord {
  return typeof v === 'object' && v !== null && !Array.isArray(v);
}

function asRecord(v: unknown, errors: string[], path: string): UnknownRecord {
  if (!isRecord(v)) {
    errors.push(`${path} was not an object; defaulting.`);
    return {};
  }
  return v;
}

function toString(v: unknown, fallback: any): any {
  if (typeof v === 'string') return v;
  if (typeof v === 'number' || typeof v === 'boolean') return String(v);
  return fallback;
}

function toBool(v: unknown, fallback: boolean): boolean {
  if (typeof v === 'boolean') return v;
  if (v === 'true') return true;
  if (v === 'false') return false;
  return fallback;
}

function toInt(v: unknown, fallback: number, errors: string[], path: string): number {
  if (typeof v === 'number' && Number.isFinite(v)) return Math.floor(v);
  if (typeof v === 'string') {
    const n = Number(v);
    if (Number.isFinite(n)) return Math.floor(n);
  }
  if (v != null) errors.push(`${path} was not a valid number; defaulting.`);
  return fallback;
}

function toEnum<T extends string>(
  v: unknown,
  allowed: readonly T[],
  fallback: T,
  errors: string[],
  path: string
): T {
  if (typeof v === 'string' && (allowed as readonly string[]).includes(v)) return v as T;
  if (v != null) errors.push(`${path} was not one of [${allowed.join(', ')}]; defaulting.`);
  return fallback;
}

function normalizeBaseUrl(url: string): string {
  const u = (url || '').trim();
  if (!u) return u;
  // Remove trailing slashes only (keep protocol intact)
  return u.replace(/\/+$/, '');
}

function deepClone<T>(obj: T): T {
  // Safe for plain JSON-like data (which AppConfig is).
  return JSON.parse(JSON.stringify(obj)) as T;
}
