import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import type { AppConfig, CloudApiKeys, ProviderEndpoints, ProviderKind, TooltipMode, ViewMode } from './config/appConfig';
import { getDefaultAppConfig } from './config/appConfig';
import { saveAppConfig } from './config/appConfigStorage';

type Role = 'user' | 'assistant' | 'system';

/**
 * Internal storage format for chat messages (separate from the serialized Message type).
 */
export type ChatMessage = {
  id: string;
  role: Role;
  content: string;
  createdAt: number;
};

/**
 * Internal storage format for sessions.
 */
export type ChatSession = {
  id: string;
  title: string;
  createdAt: number;
  updatedAt: number;
};

type ProviderConfig = {
  ollamaBaseUrl: string;
  lmStudioBaseUrl: string;
  cloudKeys: CloudApiKeys;
  endpoints: ProviderEndpoints;
};

// State shape - data only (no functions)
/**
 * Read-only data state of the global store.
 * Use useStore().state to access these values.
 */
export type StoreState = {
  viewMode: ViewMode;
  tooltipMode: TooltipMode;
  leftCollapsed: boolean;
  rightCollapsed: boolean;
  currentProvider: ProviderKind;
  modelByProvider: Record<ProviderKind, string>;
  modelName: string; // Convenience getter for current model
  sessions: ChatSession[];
  activeSessionId: string | null;
  messagesBySession: Record<string, ChatMessage[]>;
  providerConfig: ProviderConfig;
  composerText: string;
  selectedMessage: ChatMessage | null;
};

// Actions shape - functions only
/**
 * Available actions to mutate the store state.
 * Use useStore().actions to call these methods.
 */
export type StoreActions = {
  setViewMode: (mode: ViewMode) => void;
  setTooltipMode: (mode: TooltipMode) => void;
  setLeftCollapsed: (v: boolean) => void;
  setRightCollapsed: (v: boolean) => void;
  toggleLeftCollapsed: () => void;
  toggleRightCollapsed: () => void;
  setCurrentProvider: (p: ProviderKind) => void;
  setProvider: (p: ProviderKind) => void; // Alias for setCurrentProvider
  setModelForProvider: (provider: ProviderKind, model: string) => void;
  setModel: (model: string) => void; // Sets model for current provider
  createSession: () => string;
  createSessionAndActivate: () => string;
  setActiveSession: (id: string | null) => void;
  deleteSession: (id: string) => void;
  renameSession: (id: string, title: string) => void;
  addMessage: (sessionId: string, msg: ChatMessage) => void;
  clearMessages: (sessionId: string) => void;
  setProviderBaseUrl: (provider: 'ollama' | 'lmstudio', url: string) => void;
  setOllamaBaseUrl: (url: string) => void;
  setLmStudioBaseUrl: (url: string) => void;
  setCloudKey: (key: keyof CloudApiKeys, value: string) => void;
  setComposerText: (text: string) => void;
  sendMessage: (text: string) => void;
  stopGeneration: () => void;
  setSelectedMessage: (msg: ChatMessage | null) => void;
};

// Combined type for backward compatibility
type CombinedStoreState = StoreState & StoreActions;

// The context holds the combined state + actions
const StoreCtx = createContext<{ state: StoreState; actions: StoreActions } | null>(null);

function now() {
  return Date.now();
}

function uid(prefix = 'id') {
  return `${prefix}_${Math.random().toString(16).slice(2)}_${Date.now().toString(16)}`;
}

function seedFromConfig(cfg?: AppConfig) {
  const d = getDefaultAppConfig();
  const base = cfg ?? d;

  const sessions = base.chats?.sessions?.length ? base.chats.sessions : [];
  const activeSessionId =
    base.chats?.activeSessionId && sessions.some((s) => s.id === base.chats?.activeSessionId)
      ? base.chats.activeSessionId
      : sessions[0]?.id ?? null;

  const messagesBySession = base.chats?.messagesBySession ?? {};

  return {
    viewMode: base.ui?.viewMode ?? d.ui.viewMode,
    tooltipMode: base.ui?.tooltipMode ?? d.ui.tooltipMode,
    leftCollapsed: base.ui?.leftCollapsed ?? d.ui.leftCollapsed,
    rightCollapsed: base.ui?.rightCollapsed ?? d.ui.rightCollapsed,

    currentProvider: base.model?.provider ?? d.model.provider,
    modelByProvider: (() => {
      let local = base.modelByProvider?.local ?? d.model.modelName;
      let cloud = base.modelByProvider?.cloud ?? 'gemini-3-flash-preview';

      // Normalize legacy/cloud model names
      if (cloud.toLowerCase().includes('pro')) cloud = 'gemini-3-pro-preview';
      else if (cloud.toLowerCase().includes('flash')) cloud = 'gemini-3-flash-preview';
      else if (cloud.startsWith('gemini-') && !cloud.includes('preview')) cloud = 'gemini-3-flash-preview';

      // If relying on old single-model config
      if (base.model?.modelName && !base.modelByProvider) {
        if (base.model.provider === 'cloud') cloud = base.model.modelName; // Will likely get normalized on next load if invalid, but respected for now if valid
        else local = base.model.modelName;
      }

      return { local, cloud };
    })(),

    sessions,
    activeSessionId,
    messagesBySession,

    providerConfig: {
      ollamaBaseUrl: base.providers?.endpoints?.ollamaBaseUrl ?? d.providers.endpoints.ollamaBaseUrl,
      lmStudioBaseUrl: base.providers?.endpoints?.lmStudioBaseUrl ?? d.providers.endpoints.lmStudioBaseUrl,
      cloudKeys: {
        gemini: base.providers?.cloudKeys?.gemini ?? '',
      },
      endpoints: {
        ...(d.providers.endpoints || {}),
        ...(base.providers?.endpoints || {}),
      },
    },
  };
}

export function StoreProvider({
  children,
  initialConfig,
}: {
  children: React.ReactNode;
  initialConfig?: AppConfig;
}) {
  const seed = useMemo(() => seedFromConfig(initialConfig), [initialConfig]);

  const [viewMode, setViewMode] = useState<ViewMode>(seed.viewMode);
  const [tooltipMode, setTooltipMode] = useState<TooltipMode>(seed.tooltipMode);

  const [leftCollapsed, setLeftCollapsed] = useState<boolean>(seed.leftCollapsed);
  const [rightCollapsed, setRightCollapsed] = useState<boolean>(seed.rightCollapsed);

  const [currentProvider, setCurrentProvider] = useState<ProviderKind>(seed.currentProvider);
  const [modelByProvider, setModelByProvider] = useState<Record<ProviderKind, string>>(seed.modelByProvider);

  const [sessions, setSessions] = useState<ChatSession[]>(seed.sessions);
  const [activeSessionId, setActiveSessionId] = useState<string | null>(seed.activeSessionId);
  const [messagesBySession, setMessagesBySession] = useState<Record<string, ChatMessage[]>>(seed.messagesBySession);

  const [providerConfig, setProviderConfig] = useState<ProviderConfig>(() => ({
    ...seed.providerConfig,
    cloudKeys: seed.providerConfig?.cloudKeys ?? { gemini: '' },
  }));

  // New state for App.tsx compatibility
  const [composerText, setComposerText] = useState<string>('');
  const [selectedMessage, setSelectedMessage] = useState<ChatMessage | null>(null);

  // Persist to IndexedDB (via appConfigStorage)
  const lastSavedRef = useRef<number>(0);
  const saveTimerRef = useRef<number | null>(null);

  const buildConfigForSave = useCallback((): AppConfig => {
    const baseConfig = initialConfig ?? getDefaultAppConfig();
    return {
      ...baseConfig,
      ui: {
        ...(baseConfig.ui || {}),
        viewMode,
        tooltipMode,
        leftCollapsed,
        rightCollapsed,
      },
      model: {
        provider: currentProvider,
        modelName: modelByProvider[currentProvider] || '',
      },
      chats: {
        sessions,
        activeSessionId,
        messagesBySession,
      },
      providers: {
        ...(baseConfig.providers || {}),
        endpoints: {
          ...(baseConfig.providers?.endpoints || {}),
          ollamaBaseUrl: providerConfig.ollamaBaseUrl,
          lmStudioBaseUrl: providerConfig.lmStudioBaseUrl,
        },
        cloudKeys: {
          ...(baseConfig.providers?.cloudKeys || {}),
          gemini: providerConfig.cloudKeys?.gemini ?? '',
        },
      },

    };
  }, [
    activeSessionId,
    currentProvider,
    initialConfig,
    leftCollapsed,
    messagesBySession,
    modelByProvider,
    providerConfig.cloudKeys,
    providerConfig.lmStudioBaseUrl,
    providerConfig.ollamaBaseUrl,
    rightCollapsed,
    sessions,
    tooltipMode,
    viewMode,
  ]);

  useEffect(() => {
    // Debounced save to avoid spamming storage on every keystroke/click.
    if (saveTimerRef.current) window.clearTimeout(saveTimerRef.current);

    saveTimerRef.current = window.setTimeout(() => {
      const ts = Date.now();
      if (ts - lastSavedRef.current < 250) return; // guard
      lastSavedRef.current = ts;

      const cfg = buildConfigForSave();
      saveAppConfig(cfg).catch(() => {
        // Ignore persistence failures; UI should still function.
      });
    }, 300);

    return () => {
      if (saveTimerRef.current) window.clearTimeout(saveTimerRef.current);
    };
  }, [buildConfigForSave]);

  // === ACTION CALLBACKS ===

  const setModelForProvider = useCallback((provider: ProviderKind, model: string) => {
    setModelByProvider((prev) => ({ ...prev, [provider]: model }));
  }, []);

  const setModel = useCallback((model: string) => {
    setModelByProvider((prev) => ({ ...prev, [currentProvider]: model }));
  }, [currentProvider]);

  const toggleLeftCollapsed = useCallback(() => {
    setLeftCollapsed((prev) => !prev);
  }, []);

  const toggleRightCollapsed = useCallback(() => {
    setRightCollapsed((prev) => !prev);
  }, []);

  const createSession = useCallback(() => {
    const id = uid('chat');
    const ts = now();
    const session: ChatSession = { id, title: 'New chat', createdAt: ts, updatedAt: ts };
    setSessions((prev) => [session, ...prev]);
    setActiveSessionId(id);
    setMessagesBySession((prev) => ({ ...prev, [id]: [] }));
    return id;
  }, []);

  // Alias for createSession (same behavior)
  const createSessionAndActivate = createSession;

  const setActiveSession = useCallback((id: string | null) => {
    setActiveSessionId(id);
  }, []);

  const deleteSession = useCallback((id: string) => {
    setSessions((prev) => prev.filter((s) => s.id !== id));
    setMessagesBySession((prev) => {
      const next = { ...prev };
      delete next[id];
      return next;
    });
    setActiveSessionId((prev) => (prev === id ? null : prev));
  }, []);

  const renameSession = useCallback((id: string, title: string) => {
    setSessions((prev) => prev.map((s) => (s.id === id ? { ...s, title, updatedAt: now() } : s)));
  }, []);

  const addMessage = useCallback((sessionId: string, msg: ChatMessage) => {
    setMessagesBySession((prev) => {
      const list = prev[sessionId] ?? [];
      return { ...prev, [sessionId]: [...list, msg] };
    });
    setSessions((prev) => prev.map((s) => (s.id === sessionId ? { ...s, updatedAt: now() } : s)));
  }, []);

  const clearMessages = useCallback((sessionId: string) => {
    setMessagesBySession((prev) => ({ ...prev, [sessionId]: [] }));
  }, []);

  const setProviderBaseUrl = useCallback((provider: 'ollama' | 'lmstudio', url: string) => {
    setProviderConfig((prev) => ({
      ...prev,
      [provider === 'ollama' ? 'ollamaBaseUrl' : 'lmStudioBaseUrl']: url,
    }));
  }, []);

  const setOllamaBaseUrl = useCallback((url: string) => {
    setProviderConfig((prev) => ({
      ...prev,
      ollamaBaseUrl: url,
    }));
  }, []);

  const setLmStudioBaseUrl = useCallback((url: string) => {
    setProviderConfig((prev) => ({
      ...prev,
      lmStudioBaseUrl: url,
    }));
  }, []);

  const setCloudKey = useCallback((key: keyof CloudApiKeys, value: string) => {
    setProviderConfig((prev) => ({
      ...prev,
      cloudKeys: {
        ...(prev.cloudKeys ?? { gemini: '' }),
        [key]: value,
      },
    }));
  }, []);

  // Send message action: adds user message and clears composer
  const sendMessage = useCallback((text: string) => {
    if (!activeSessionId) return;
    const userMsg: ChatMessage = {
      id: uid('msg'),
      role: 'user',
      content: text,
      createdAt: now(),
    };
    setMessagesBySession((prev) => {
      const list = prev[activeSessionId] ?? [];
      return { ...prev, [activeSessionId]: [...list, userMsg] };
    });
    setSessions((prev) => prev.map((s) => (s.id === activeSessionId ? { ...s, updatedAt: now() } : s)));
    setComposerText('');
    // Note: Actual AI response would be handled by a separate async process
  }, [activeSessionId]);

  // Placeholder for stopping generation (would be implemented with streaming)
  const stopGeneration = useCallback(() => {
    // TODO: Implement actual stop logic when streaming is added
  }, []);

  // === BUILD STATE OBJECT ===
  const state: StoreState = useMemo(
    () => ({
      viewMode,
      tooltipMode,
      leftCollapsed,
      rightCollapsed,
      currentProvider,
      modelByProvider,
      modelName: modelByProvider[currentProvider] || '',
      sessions,
      activeSessionId,
      messagesBySession,
      providerConfig,
      composerText,
      selectedMessage,
    }),
    [
      viewMode,
      tooltipMode,
      leftCollapsed,
      rightCollapsed,
      currentProvider,
      modelByProvider,
      sessions,
      activeSessionId,
      messagesBySession,
      providerConfig,
      composerText,
      selectedMessage,
    ]
  );

  // === BUILD ACTIONS OBJECT ===
  const actions: StoreActions = useMemo(
    () => ({
      setViewMode,
      setTooltipMode,
      setLeftCollapsed,
      setRightCollapsed,
      toggleLeftCollapsed,
      toggleRightCollapsed,
      setCurrentProvider,
      setProvider: setCurrentProvider, // Alias
      setModelForProvider,
      setModel,
      createSession,
      createSessionAndActivate,
      setActiveSession,
      deleteSession,
      renameSession,
      addMessage,
      clearMessages,
      setProviderBaseUrl,
      setOllamaBaseUrl,
      setLmStudioBaseUrl,
      setCloudKey,
      setComposerText,
      sendMessage,
      stopGeneration,
      setSelectedMessage,
    }),
    [
      addMessage,
      clearMessages,
      createSession,
      createSessionAndActivate,
      deleteSession,
      renameSession,
      sendMessage,
      setActiveSession,
      setCloudKey,
      setModel,
      setModelForProvider,
      setProviderBaseUrl,
      setOllamaBaseUrl,
      setLmStudioBaseUrl,
      stopGeneration,
      toggleLeftCollapsed,
      toggleRightCollapsed,
    ]
  );

  const ctx = useMemo(() => ({ state, actions }), [state, actions]);

  return <StoreCtx.Provider value={ctx}>{children}</StoreCtx.Provider>;
}

/**
 * Hook to access the store.
 * Returns { state, actions } for use in components.
 * 
 * @example
 * const { state, actions } = useStore();
 * console.log(state.currentProvider);
 * actions.setCurrentProvider('cloud');
 */
export function useStore(): { state: StoreState; actions: StoreActions } {
  const ctx = useContext(StoreCtx);
  if (!ctx) throw new Error('useStore must be used inside <StoreProvider>.');
  return ctx;
}

/**
 * Hook to access only the state (for compatibility with flat usage).
 * Returns a combined object with both state and actions flattened.
 */
export function useStoreFlat(): CombinedStoreState {
  const { state, actions } = useStore();
  return useMemo(() => ({ ...state, ...actions }), [state, actions]);
}