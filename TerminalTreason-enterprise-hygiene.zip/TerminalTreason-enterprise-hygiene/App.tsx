import React, { useState, useEffect, useRef } from 'react';
import {
  Menu, X, Settings, MessageSquare, Terminal, Activity,
  ChevronDown,
  AlertCircle, Zap, Shield, Cpu
} from 'lucide-react';
import { DEFAULT_GATEWAY_KEY } from './src/config/appConfig';
import { Button, Input, Badge } from './components/Shared';
import { MOCK_LOGS } from './constants';
import { useStore, type ChatMessage } from './src/store';

// Extracted components
import Tooltip from './components/Tooltip';
import Sidebar from './components/Sidebar';
import InspectorPanel from './components/InspectorPanel';
import ProviderSettings from './components/ProviderSettings';
import ConfirmDeleteModal from './components/ConfirmDeleteModal';

export default function App() {
  const { state, actions } = useStore();

  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [mobileLogsOpen, setMobileLogsOpen] = useState(false);

  const leftCollapsed = state.leftCollapsed;
  const rightCollapsed = state.rightCollapsed;

  const [pendingDeleteId, setPendingDeleteId] = useState<string | null>(null);
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);

  const [modelPickerOpen, setModelPickerOpen] = useState(false);
  const [pendingProvider, setPendingProvider] = useState<'local' | 'cloud'>(() => state.currentProvider);

  useEffect(() => {
    if (!modelPickerOpen) setPendingProvider(state.currentProvider);
  }, [state.currentProvider, modelPickerOpen]);

  const [healthOpen, setHealthOpen] = useState(false);

  const chatEndRef = useRef<HTMLDivElement | null>(null);
  const composerInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [state.activeSessionId, state.messagesBySession]);

  const currentView = state.viewMode;

  const activeSession = state.sessions.find(s => s.id === state.activeSessionId) || null;
  const activeMessages = state.activeSessionId ? (state.messagesBySession?.[state.activeSessionId] || []) : [];

  const healthStatus = {
    local: { ok: true, text: 'Local runtime OK', icon: Zap },
    cloud: { ok: true, text: 'Cloud providers ready', icon: Cpu },
    guard: { ok: false, text: 'Guard checks pending', icon: Shield },
  } as const;

  // --- API INTERACTION ---
  useEffect(() => {
    if (!state.activeSessionId) return;
    const msgs = state.messagesBySession[state.activeSessionId] || [];
    if (msgs.length === 0) return;
    const lastMsg = msgs[msgs.length - 1];

    if (lastMsg.role === 'user') {
      const sessionId = state.activeSessionId;
      const model = state.modelName;
      const providerId = state.currentProvider === 'local' ? 'local-main' : 'gemini';

      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${DEFAULT_GATEWAY_KEY}`
      };

      // Enterprise Security: Client does NOT send key. Gateway uses secure store.

      fetch('http://127.0.0.1:8787/v1/chat/completions', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          model,
          messages: msgs.map(m => ({ role: m.role, content: m.content })),
          providerId,
          metadata: { sessionId }
        })
      })
        .then(res => res.json())
        .then(data => {
          let content = '';
          if (typeof data === 'string') {
            content = data;
          } else if (data && data.output && data.output.content) {
            content = data.output.content;
          }

          if (content) {
            const assistantMsg: ChatMessage = {
              id: 'msg_' + Date.now(),
              role: 'assistant',
              content: content,
              createdAt: new Date().toISOString()
            };
            actions.addMessage(sessionId, assistantMsg);
          }
        })
        .catch(err => {
          console.error("API Error", err);
        });
    }
  }, [state.activeSessionId, state.messagesBySession]);

  const handleNewChat = () => {
    actions.createSessionAndActivate();
    setMobileNavOpen(false);
    requestAnimationFrame(() => composerInputRef.current?.focus());
  };

  const handleSelectSession = (id: string) => {
    actions.setActiveSession(id);
    setMobileNavOpen(false);
    requestAnimationFrame(() => composerInputRef.current?.focus());
  };

  const handleRequestDelete = (id: string) => {
    setPendingDeleteId(id);
    setDeleteModalOpen(true);
  };

  const handleConfirmDelete = () => {
    if (pendingDeleteId) actions.deleteSession(pendingDeleteId);
    setPendingDeleteId(null);
    setDeleteModalOpen(false);
  };

  const handleCancelDelete = () => {
    setPendingDeleteId(null);
    setDeleteModalOpen(false);
  };

  const handleSend = () => {
    if (!state.composerText.trim()) return;
    actions.sendMessage(state.composerText.trim());
    requestAnimationFrame(() => composerInputRef.current?.focus());
  };

  return (
    <div className="h-screen w-full bg-obsidian text-platinum flex overflow-hidden">
      {mobileNavOpen && (
        <div className="fixed inset-0 z-[9998] bg-black/60 lg:hidden" onClick={() => setMobileNavOpen(false)}>
          <div className="absolute inset-y-0 left-0 w-[320px] bg-panel border-r border-border" onClick={(e) => e.stopPropagation()}>
            <Sidebar
              sessions={state.sessions}
              activeSessionId={state.activeSessionId}
              onNewChat={handleNewChat}
              onSelectSession={handleSelectSession}
              onDeleteSession={handleRequestDelete}
            />
          </div>
        </div>
      )}

      {!leftCollapsed && (
        <div className="hidden lg:block w-[320px]">
          <Sidebar
            sessions={state.sessions}
            activeSessionId={state.activeSessionId}
            onNewChat={handleNewChat}
            onSelectSession={handleSelectSession}
            onDeleteSession={handleRequestDelete}
          />
        </div>
      )}

      <div className="flex-1 flex flex-col min-w-0">
        <header className="h-14 border-b border-border bg-panel flex items-center justify-between px-3 relative">
          <div className="flex items-center gap-2">
            <Button variant="ghost" className="lg:hidden" onClick={() => setMobileNavOpen(true)}>
              <Menu size={18} />
            </Button>

            <div className="flex items-center gap-2">
              <Badge className="bg-neon/10 text-neon border border-neon/20 font-mono text-[10px] tracking-widest">
                {activeSession ? activeSession.title : 'NO SESSION'}
              </Badge>
            </div>
          </div>

          <div className={`absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-30 ${currentView === 'settings' || rightCollapsed ? '' : 'lg:-ml-[180px]'}`}>
            <div className="relative">
              <button
                onClick={() => setModelPickerOpen(v => !v)}
                className="flex items-center gap-2 px-3 py-1.5 rounded-full border border-border bg-black/20 hover:bg-black/30 text-xs font-mono"
              >
                <span className="text-platinum/70">{pendingProvider === 'local' ? 'Local' : 'Cloud'}</span>
                <span className="text-platinum/40">{'\u2022'}</span>
                <span className="text-platinum">{state.modelName}</span>
                <ChevronDown size={14} className="text-platinum/60" />
              </button>

              {modelPickerOpen && (
                <div className="absolute top-full mt-2 left-0 w-[320px] bg-panel border border-border rounded-lg shadow-neon p-2 z-50">
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => setPendingProvider('local')}
                      className={`p-2 rounded border text-left ${pendingProvider === 'local' ? 'border-neon/20 bg-neon/5' : 'border-border hover:bg-platinum/5'}`}
                    >
                      <div className="text-xs font-mono text-platinum/60 uppercase tracking-widest">Local</div>
                      <div className="text-sm text-platinum mt-1">Ollama / LM Studio</div>
                    </button>
                    <button
                      onClick={() => setPendingProvider('cloud')}
                      className={`p-2 rounded border text-left ${pendingProvider === 'cloud' ? 'border-neon/20 bg-neon/5' : 'border-border hover:bg-platinum/5'}`}
                    >
                      <div className="text-xs font-mono text-platinum/60 uppercase tracking-widest">Cloud</div>
                      <div className="text-sm text-platinum mt-1">OpenAI / Anthropic / Gemini</div>
                    </button>
                  </div>

                  <div className="mt-2 border-t border-border pt-2">
                    {pendingProvider === 'local' ? (
                      <div className="space-y-1">
                        {['llama3.1:8b', 'qwen2.5-coder:7b', 'deepseek-r1:8b'].map(m => (
                          <button
                            key={m}
                            onClick={() => { actions.setModelForProvider('local', m); actions.setProvider('local'); setModelPickerOpen(false); }}
                            className="w-full text-left px-2 py-1.5 text-sm hover:bg-platinum/5 rounded text-platinum"
                          >
                            {m}
                          </button>
                        ))}
                      </div>
                    ) : (
                      <div className="space-y-1">
                        {[
                          { id: 'gemini-3-pro-preview', name: 'Gemini 3 Pro (Preview)' },
                          { id: 'gemini-3-flash-preview', name: 'Gemini 3 Flash (Preview)' }
                        ].map(m => (
                          <button
                            key={m.id}
                            onClick={() => { actions.setModelForProvider('cloud', m.id); actions.setProvider('cloud'); setModelPickerOpen(false); }}
                            className="w-full text-left px-2 py-1.5 text-sm hover:bg-platinum/5 rounded text-platinum"
                          >
                            {m.name}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="hidden lg:flex items-center gap-1">
              <Button
                variant="ghost"
                className="px-2"
                title={leftCollapsed ? 'Expand left panel' : 'Collapse left panel'}
                onClick={() => actions.toggleLeftCollapsed?.()}
              >
                <span className="text-[10px] font-mono tracking-widest">{leftCollapsed ? 'L+' : 'L-'}</span>
              </Button>
              <Button
                variant="ghost"
                className="px-2"
                title={rightCollapsed ? 'Expand inspector panel' : 'Collapse inspector panel'}
                onClick={() => actions.toggleRightCollapsed?.()}
              >
                <span className="text-[10px] font-mono tracking-widest">{rightCollapsed ? 'R+' : 'R-'}</span>
              </Button>
            </div>
            <div className="hidden md:flex items-center gap-2">
              {Object.entries(healthStatus).map((entry) => {
                if (!entry) return null;
                const key = entry[0];
                const v = entry[1];
                if (!key || !v) return null;
                const Icon = v.icon || Activity;
                return (
                  <span key={key}>
                    <Tooltip text={v.text}>
                      <button
                        onClick={() => setHealthOpen(true)}
                        className={`flex items-center gap-1 px-2 py-1 rounded-full text-[10px] font-mono border ${v.ok ? 'border-neon/20 text-neon bg-neon/5' : 'border-danger/20 text-danger bg-danger/5'
                          }`}
                      >
                        <Icon size={12} />
                        <span>{String(key).toUpperCase()}</span>
                      </button>
                    </Tooltip>
                  </span>
                );
              })}
            </div>

            <Button variant="ghost" onClick={() => setMobileLogsOpen(true)} className="lg:hidden">
              <Activity size={18} />
            </Button>

            <Button variant="ghost" onClick={() => actions.setViewMode?.('settings')}>
              <Settings size={18} />
            </Button>
          </div>
        </header>

        <div className="flex-1 flex min-h-0">
          {currentView === 'settings' ? (
            <ProviderSettings onClose={() => actions.setViewMode?.('chat')} />
          ) : (
            <>
              <main className="flex-1 flex flex-col min-w-0">
                <div className="flex-1 overflow-y-auto p-4 space-y-3">
                  {activeMessages.length === 0 ? (
                    <div className="h-full flex flex-col items-center justify-center text-center text-platinum/50">
                      <Terminal size={42} className="text-neon/70" />
                      <div className="mt-4 text-lg text-platinum">TerminalTreason</div>
                      <div className="mt-1 text-sm max-w-[520px]">
                        Start a new session or select a recent chat to begin.
                      </div>
                    </div>
                  ) : (
                    activeMessages.map((m) => (
                      <div key={m.id} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                        <div
                          onClick={() => actions.setSelectedMessage(m)}
                          className={`max-w-[75%] rounded-lg border px-3 py-2 cursor-pointer ${m.role === 'user'
                            ? 'bg-neon/10 border-neon/20 text-platinum'
                            : 'bg-black/30 border-border text-platinum/90'
                            }`}
                        >
                          <div className="text-[10px] font-mono text-platinum/50 uppercase tracking-widest">
                            {m.role === 'user' ? 'DEVELOPER' : m.role === 'system' ? 'SYSTEM' : 'AI ASSET'}
                          </div>
                          <div className="mt-1 whitespace-pre-wrap text-sm leading-relaxed">
                            {m.content}
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                  <div ref={chatEndRef} />
                </div>

                <div className="border-t border-border bg-panel p-3">
                  <div className="flex items-end gap-2">
                    <div className="flex-1">
                      <Input
                        ref={composerInputRef}
                        value={state.composerText}
                        onChange={(e) => actions.setComposerText(e.target.value)}
                        placeholder="Type a prompt…"
                        className="bg-black/30 border-border"
                        onKeyDown={(e) => {
                          if (e.key === 'Escape') {
                            e.preventDefault();
                            e.stopPropagation();
                            actions.stopGeneration();
                            return;
                          }
                          if (e.key === 'Enter' && !e.shiftKey) {
                            e.preventDefault();
                            handleSend();
                          }
                        }}
                      />
                    </div>
                    <Button onClick={handleSend} variant="primary" className="!text-amber-200 !border-amber-200/60 !bg-amber-200/10 hover:!bg-amber-200/20">Send</Button>
                  </div>
                </div>
              </main>

              {!rightCollapsed && (
                <div className="hidden lg:block w-[360px]">
                  <InspectorPanel logs={MOCK_LOGS} selectedMessage={state.selectedMessage} />
                </div>
              )}
            </>
          )}
        </div>
      </div>



      {mobileLogsOpen && (
        <div className="fixed inset-0 z-[9998] bg-black/60 lg:hidden" onClick={() => setMobileLogsOpen(false)}>
          <div className="absolute inset-y-0 right-0 w-[360px] bg-panel border-l border-border" onClick={(e) => e.stopPropagation()}>
            <div className="p-3 border-b border-border flex items-center justify-between">
              <div className="text-xs font-mono text-platinum/60 uppercase tracking-widest">Inspector</div>
              <Button variant="ghost" onClick={() => setMobileLogsOpen(false)}><X size={16} /></Button>
            </div>
            <InspectorPanel logs={MOCK_LOGS} selectedMessage={state.selectedMessage} />
          </div>
        </div>
      )}

      {healthOpen && (
        <div className="fixed inset-0 z-[9999] bg-black/70 flex items-center justify-center" onClick={() => setHealthOpen(false)}>
          <div className="w-[420px] bg-panel border border-border rounded-lg shadow-neon p-4" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between">
              <div className="text-neon font-bold tracking-wider flex items-center gap-2">
                <Activity size={18} />
                <span>HEALTH</span>
              </div>
              <Button variant="ghost" onClick={() => setHealthOpen(false)}><X size={16} /></Button>
            </div>
            <div className="mt-3 space-y-2 text-sm text-platinum/80">
              {Object.entries(healthStatus).map((entry) => {
                if (!entry) return null;
                const k = entry[0];
                const v = entry[1];
                if (!k || !v) return null;
                const Icon = v.icon || Activity;
                return (
                  <div
                    key={k}
                    className={`p-2 rounded border ${v.ok ? 'border-neon/20 bg-neon/5' : 'border-danger/20 bg-danger/5'}`}
                  >
                    <div className="flex items-center gap-2">
                      <Icon size={16} className={v.ok ? 'text-neon' : 'text-danger'} />
                      <div className="font-mono text-xs uppercase tracking-widest">{String(k)}</div>
                    </div>
                    <div className="mt-1 text-platinum/70">{v.text}</div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      <ConfirmDeleteModal
        open={deleteModalOpen}
        onCancel={handleCancelDelete}
        onConfirm={handleConfirmDelete}
      />
    </div>
  );
}