Set-Location $PSScriptRoot\..\
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
if (-not $env:TT_LOCAL_BASE_URL) { $env:TT_LOCAL_BASE_URL = "http://127.0.0.1:8080" }
uvicorn app.main:app --host 127.0.0.1 --port 8787 --reload
