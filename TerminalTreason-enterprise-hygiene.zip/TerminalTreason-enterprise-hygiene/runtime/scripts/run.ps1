# Run the TerminalTreason gateway (Windows PowerShell)
# From the project root:
#   cd runtime
#   .\scripts\run.ps1

Set-Location $PSScriptRoot\..

if (!(Test-Path .venv)) {
  python -m venv .venv
}

.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m uvicorn app.main:app --host 127.0.0.1 --port 8787 --reload
