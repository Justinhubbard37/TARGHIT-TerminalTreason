#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export TT_LOCAL_BASE_URL="${TT_LOCAL_BASE_URL:-http://127.0.0.1:8080}"
uvicorn app.main:app --host 127.0.0.1 --port 8787 --reload
