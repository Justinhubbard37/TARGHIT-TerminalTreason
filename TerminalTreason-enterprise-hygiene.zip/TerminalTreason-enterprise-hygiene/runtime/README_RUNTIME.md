# TerminalTreason Local Gateway (FastAPI)

## What this is
A **local-only** gateway the UI will talk to (127.0.0.1). It implements a stable runner API contract so you can swap runtimes forever without rewriting the front-end.

Contract endpoints implemented:
- `GET /v1/health`
- `GET /v1/models`
- `POST /v1/chat/completions` (supports SSE streaming)
- `POST /v1/generate/stop` (stub)
- `POST /v1/providers/test`
- `GET /v1/sessions` (placeholder for future)
- `GET /v1/logs`

The gateway **does not store cloud keys**. Keys stay in your browser (IndexedDB) and, later, the UI can pass a key per request when you intentionally call cloud.

## Install + run
From the project root:

### Windows PowerShell
```powershell
cd .\runtime
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python -m uvicorn app.main:app --host 127.0.0.1 --port 8787 --reload
```

### macOS/Linux
```bash
cd ./runtime
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python -m uvicorn app.main:app --host 127.0.0.1 --port 8787 --reload
```

Then hit:
- `http://127.0.0.1:8787/v1/health`

## Local engine (llama.cpp)
This gateway assumes you will run a local OpenAI-compatible server for inference. `llama.cpp` ships one (`llama-server`).

Example:
```bash
llama-server -m /path/to/model.gguf --port 8080
```

Set the gateway env var (optional):
- `TT_LOCAL_BASE_URL=http://127.0.0.1:8080`

## CORS
The gateway enables CORS for common dev origins (`http://localhost:3000` and Vite defaults). If you change your UI port, set:
- `TT_CORS_ORIGINS=http://localhost:3000,http://127.0.0.1:3000`
