import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import { StoreProvider } from './src/store';
import { ErrorBoundary } from './components/ErrorBoundary';
import { loadAppConfig } from './src/config/appConfigStorage';
import { getDefaultAppConfig } from './src/config/appConfig';

const rootElement = document.getElementById('root');
if (!rootElement) {
  throw new Error("Could not find root element to mount to");
}

const root = ReactDOM.createRoot(rootElement);

(async () => {
  const fallback = getDefaultAppConfig();
  let initialConfig = fallback;

  try {
    const loaded = await loadAppConfig();
    if (loaded?.config) initialConfig = loaded.config;
  } catch {
    // If IndexedDB load fails for any reason, we still boot with defaults.
    initialConfig = fallback;
  }

  root.render(
    <React.StrictMode>
      <ErrorBoundary>
        <StoreProvider initialConfig={initialConfig}>
          <App />
        </StoreProvider>
      </ErrorBoundary>
    </React.StrictMode>
  );
})();