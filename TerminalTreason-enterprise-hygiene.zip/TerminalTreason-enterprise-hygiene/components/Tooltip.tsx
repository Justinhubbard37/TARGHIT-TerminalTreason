import React, { useState, useEffect, useRef, useId } from 'react';
import { createPortal } from 'react-dom';

export type TooltipProps = { children: React.ReactNode; text: string };

const Tooltip = ({ children, text }: TooltipProps) => {
    const id = useId();
    const triggerRef = useRef<HTMLSpanElement | null>(null);
    const tooltipRef = useRef<HTMLDivElement | null>(null);
    const debounceRef = useRef<number | null>(null);

    const [open, setOpen] = useState(false);
    const [pos, setPos] = useState<{ top: number; left: number; placement: 'top' | 'bottom' } | null>(null);

    const computePosition = () => {
        const triggerEl = triggerRef.current;
        const tooltipEl = tooltipRef.current;
        if (!triggerEl || !tooltipEl) return;

        const MARGIN = 8;
        const GAP = 8;

        const r = triggerEl.getBoundingClientRect();

        const tw = tooltipEl.offsetWidth;
        const th = tooltipEl.offsetHeight;

        const vw = window.innerWidth;
        const vh = window.innerHeight;

        let placement: 'top' | 'bottom' = 'top';
        let top = r.top - th - GAP;

        if (top < MARGIN) {
            placement = 'bottom';
            top = r.bottom + GAP;
        }

        top = Math.min(Math.max(top, MARGIN), vh - MARGIN - th);

        const centeredLeft = r.left + r.width / 2 - tw / 2;
        let left = centeredLeft;

        if (centeredLeft < MARGIN) {
            left = r.left;
        } else if (centeredLeft + tw > vw - MARGIN) {
            left = r.right - tw;
        }

        left = Math.min(Math.max(left, MARGIN), vw - MARGIN - tw);

        setPos({ top: Math.round(top), left: Math.round(left), placement });
    };

    const scheduleReflow = () => {
        if (debounceRef.current) window.clearTimeout(debounceRef.current);
        debounceRef.current = window.setTimeout(() => {
            requestAnimationFrame(() => requestAnimationFrame(computePosition));
        }, 60);
    };

    useEffect(() => {
        if (!open) {
            setPos(null);
            return;
        }

        requestAnimationFrame(() => requestAnimationFrame(computePosition));

        const onResize = () => scheduleReflow();
        const onScroll = () => scheduleReflow();
        const onKeyDown = (e: KeyboardEvent) => {
            if (e.key === 'Escape') setOpen(false);
        };

        window.addEventListener('resize', onResize);
        window.addEventListener('scroll', onScroll, true);
        window.addEventListener('keydown', onKeyDown);

        const vv = window.visualViewport;
        if (vv) vv.addEventListener('resize', onResize);

        return () => {
            if (debounceRef.current) window.clearTimeout(debounceRef.current);
            window.removeEventListener('resize', onResize);
            window.removeEventListener('scroll', onScroll, true);
            window.removeEventListener('keydown', onKeyDown);
            if (vv) vv.removeEventListener('resize', onResize);
        };
    }, [open, text]);

    const wrappedChild = React.isValidElement(children)
        ? React.cloneElement(children as any, { 'aria-describedby': open ? id : undefined })
        : children;

    return (
        <>
            <span
                ref={triggerRef}
                className="inline-flex"
                onMouseEnter={() => setOpen(true)}
                onMouseLeave={() => setOpen(false)}
                onFocusCapture={() => setOpen(true)}
                onBlurCapture={() => setOpen(false)}
                onKeyDownCapture={(e) => { if (e.key === 'Escape') setOpen(false); }}
            >
                {wrappedChild}
            </span>

            {open
                ? createPortal(
                    <div
                        ref={tooltipRef}
                        id={id}
                        role="tooltip"
                        className="fixed px-2 py-1 bg-panel border border-border text-xs text-platinum rounded shadow-neon-sm z-[9999] pointer-events-none max-w-[320px] whitespace-normal break-words"
                        style={pos ? { top: pos.top, left: pos.left } : { top: -9999, left: -9999 }}
                    >
                        {text}
                    </div>,
                    document.body
                )
                : null}
        </>
    );
};

export default Tooltip;
