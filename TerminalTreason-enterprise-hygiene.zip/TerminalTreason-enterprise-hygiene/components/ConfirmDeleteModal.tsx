import React from 'react';
import { AlertCircle } from 'lucide-react';
import { Button } from './Shared';

export interface ConfirmDeleteModalProps {
    open: boolean;
    onCancel: () => void;
    onConfirm: () => void;
}

const ConfirmDeleteModal = ({
    open,
    onCancel,
    onConfirm,
}: ConfirmDeleteModalProps) => {
    if (!open) return null;
    return (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-[9999]">
            <div className="w-[360px] bg-panel border border-border rounded-lg shadow-neon p-4">
                <div className="flex items-center gap-2 text-danger font-bold">
                    <AlertCircle size={18} />
                    <span>Delete session?</span>
                </div>
                <div className="text-sm text-platinum/70 mt-2">
                    This will remove the session from your recent list.
                </div>
                <div className="mt-4 flex justify-end gap-2">
                    <Button variant="ghost" onClick={onCancel}>Cancel</Button>
                    <Button variant="danger" onClick={onConfirm}>Delete</Button>
                </div>
            </div>
        </div>
    );
};

export default ConfirmDeleteModal;
