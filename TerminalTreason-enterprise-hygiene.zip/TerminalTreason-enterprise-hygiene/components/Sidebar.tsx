import React from 'react';
import { Terminal, MessageSquare, Search, Trash2 } from 'lucide-react';
import { Button, Input } from './Shared';
import { ChatSession } from '../src/store';
import Tooltip from './Tooltip';

export interface SidebarProps {
    className?: string;
    sessions: ChatSession[];
    activeSessionId: string | null;
    onNewChat: () => void;
    onSelectSession: (id: string) => void;
    onDeleteSession: (id: string) => void;
}

const Sidebar = ({
    className,
    sessions,
    activeSessionId,
    onNewChat,
    onSelectSession,
    onDeleteSession,
}: SidebarProps) => (
    <div className={`flex flex-col h-full bg-panel border-r border-border ${className || ''}`}>
        <div className="p-4 border-b border-border flex items-center justify-between">
            <div className="flex items-center gap-2 text-neon font-bold tracking-wider">
                <Terminal size={18} />
                <span>Terminal<span className="text-platinum">Treason</span></span>
            </div>
            <Tooltip text="New chat">
                <Button variant="ghost" onClick={onNewChat}><MessageSquare size={16} /></Button>
            </Tooltip>
        </div>

        <div className="p-3">
            <div className="relative">
                <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-platinum/60" />
                <Input placeholder="Search sessions." className="pl-9 bg-panel/70 border-border" />
            </div>
        </div>

        <div className="flex-1 overflow-y-auto px-2 space-y-1">
            <div className="px-3 py-2 text-xs font-mono text-platinum/60 uppercase tracking-widest mt-2">Recent</div>
            {sessions.map((session) => (
                <div
                    key={session.id}
                    onClick={() => onSelectSession(session.id)}
                    className={`w-full text-left px-3 py-2.5 rounded-md text-sm group transition-colors flex items-center gap-3 border cursor-pointer ${activeSessionId === session.id
                        ? 'bg-neon/10 text-neon border-neon/20'
                        : 'text-platinum border-transparent hover:bg-platinum/5 hover:text-neon'
                        }`}
                >
                    <MessageSquare size={14} className="text-platinum/60 group-hover:text-neon" />
                    <div className="flex-1 truncate">
                        <div className="truncate">{session.title}</div>
                        <div className="text-[10px] text-platinum/60 opacity-60">{session.updatedAt}</div>
                    </div>

                    <button
                        type="button"
                        onClick={(e) => { e.stopPropagation(); onDeleteSession(session.id); }}
                        className="opacity-0 group-hover:opacity-100 p-1 rounded hover:bg-danger/10 text-danger transition-opacity"
                        title="Delete session"
                    >
                        <Trash2 size={14} />
                    </button>
                </div>
            ))}
        </div>
    </div>
);

export default Sidebar;
