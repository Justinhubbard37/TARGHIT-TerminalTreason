import React, { useState, useEffect } from 'react';
import { ChatMessage } from '../src/store';
import { LogEntry } from '../types';

export interface InspectorPanelProps {
    className?: string;
    logs: LogEntry[];
    selectedMessage: ChatMessage | null;
}

const InspectorPanel = ({
    className,
    logs,
    selectedMessage
}: InspectorPanelProps) => {
    const [activeTab, setActiveTab] = useState<'logs' | 'vars' | 'trace'>('logs');

    useEffect(() => {
        if (selectedMessage) setActiveTab('vars');
    }, [selectedMessage]);

    return (
        <div className={`flex flex-col h-full bg-panel border-l border-border ${className || ''}`}>
            <div className="p-3 border-b border-border flex items-center justify-between">
                <div className="text-xs font-mono text-platinum/60 uppercase tracking-widest">Inspector</div>
                <div className="flex gap-1">
                    {(['logs', 'vars', 'trace'] as const).map(t => (
                        <button
                            key={t}
                            onClick={() => setActiveTab(t)}
                            className={`px-2 py-1 text-[10px] rounded border ${activeTab === t ? 'text-neon border-neon/20 bg-neon/5' : 'text-platinum/60 border-transparent hover:bg-platinum/5'
                                }`}
                        >
                            {t.toUpperCase()}
                        </button>
                    ))}
                </div>
            </div>

            <div className="flex-1 overflow-y-auto p-3 space-y-2">
                {activeTab === 'logs' && (
                    <>
                        {logs.map((log) => (
                            <div
                                key={log.id}
                                className={`p-2 rounded border text-xs font-mono ${log.level === 'ERROR'
                                    ? 'border-danger/20 bg-danger/5 text-danger'
                                    : log.level === 'WARN'
                                        ? 'border-ember/20 bg-ember/5 text-ember'
                                        : 'border-border bg-platinum/5 text-platinum/80'
                                    }`}
                            >
                                <div className="flex items-center justify-between">
                                    <span className="uppercase tracking-widest text-[10px] opacity-70">{log.level}</span>
                                    <span className="text-[10px] opacity-50">{log.ts}</span>
                                </div>
                                <div className="mt-1">{log.message}</div>
                            </div>
                        ))}
                    </>
                )}

                {activeTab === 'vars' && (
                    <div className="text-xs font-mono text-platinum/80">
                        {!selectedMessage ? (
                            <div className="text-platinum/50">Select a message to view variables.</div>
                        ) : (
                            <pre className="p-2 rounded bg-black/30 border border-border overflow-auto">
                                {JSON.stringify((selectedMessage as any).meta ?? {}, null, 2)}
                            </pre>
                        )}
                    </div>
                )}

                {activeTab === 'trace' && (
                    <div className="text-xs font-mono text-platinum/50">
                        Trace view placeholder.
                    </div>
                )}
            </div>
        </div>
    );
};

export default InspectorPanel;
