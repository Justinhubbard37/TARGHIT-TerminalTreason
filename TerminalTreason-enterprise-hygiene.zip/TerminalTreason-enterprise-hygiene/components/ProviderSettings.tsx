import React, { useState, useEffect } from 'react';
import { Settings, X, Terminal, HardDrive, Database, Cloud } from 'lucide-react';
import { Button, Input } from './Shared';
import { useStore } from '../src/store';
import { DEFAULT_GATEWAY_KEY } from '../src/config/appConfig';

export interface ProviderSettingsProps {
    onClose: () => void;
}

type SettingsTopTab = 'providers' | 'appearance' | 'about';
type ProviderTab = 'local' | 'ollama' | 'lmstudio' | 'cloud';

const ProviderSettings = ({ onClose }: ProviderSettingsProps) => {
    const { state, actions } = useStore();

    const [tab, setTab] = useState<SettingsTopTab>('providers');
    const [providerTab, setProviderTab] = useState<ProviderTab>('local');

    // Only Gemini is supported initially
    const [showKeys, setShowKeys] = useState<{ gemini: boolean }>({ gemini: false });

    // Draft holds user edits; we intentionally do NOT preload saved keys into the input value.
    // Saved keys are shown masked via placeholder.
    const [draft, setDraft] = useState(() => ({
        ollamaBaseUrl: state.providerConfig.ollamaBaseUrl,
        lmStudioBaseUrl: state.providerConfig.lmStudioBaseUrl,
        cloudKeys: {
            gemini: '',
        },
    }));

    useEffect(() => {
        setDraft((prev) => ({
            ...prev,
            ollamaBaseUrl: state.providerConfig.ollamaBaseUrl,
            lmStudioBaseUrl: state.providerConfig.lmStudioBaseUrl,
            cloudKeys: { gemini: '' },
        }));
    }, [
        state.providerConfig.ollamaBaseUrl,
        state.providerConfig.lmStudioBaseUrl,
        state.providerConfig.cloudKeys.gemini,
    ]);

    const [status, setStatus] = useState<{ kind: 'idle' | 'ok' | 'err'; msg: string }>({ kind: 'idle', msg: '' });
    const [testStatus, setTestStatus] = useState<'idle' | 'success' | 'error'>('idle');
    const [testMessage, setTestMessage] = useState<string>('');

    const mask = (s: string) => {
        const v = s.trim();
        if (!v) return '';
        if (v === 'SAVED') return '•••••••• (Stored Securely)';
        if (v.length <= 8) return '••••';
        return `${v.slice(0, 4)}••••••${v.slice(-4)}`;
    };

    const isLocalOnlyUrl = (url: string) => {
        try {
            const u = new URL(url);
            const host = (u.hostname || '').toLowerCase();
            return host === 'localhost' || host === '127.0.0.1';
        } catch {
            return false;
        }
    };

    // All browser-origin requests to localhost providers can be blocked by CORS.
    // So: test providers via the local gateway, which does the fetch server-side.
    const GATEWAY_BASE_URL = 'http://127.0.0.1:8787';
    const gw = (path: string) => `${GATEWAY_BASE_URL}${path.startsWith('/') ? path : `/${path}`}`;

    const fetchWithTimeout = async (url: string, timeoutMs = 2500, init?: RequestInit) => {
        const ctrl = new AbortController();
        const t = setTimeout(() => ctrl.abort(), timeoutMs);
        const start = performance.now();
        try {
            const res = await fetch(url, { ...(init || {}), signal: ctrl.signal });
            const ms = Math.round(performance.now() - start);
            return { res, ms };
        } finally {
            clearTimeout(t);
        }
    };

    const onSave = async () => {
        setStatus({ kind: 'idle', msg: '' });

        if (providerTab === 'ollama') {
            actions.setOllamaBaseUrl(draft.ollamaBaseUrl);
            setStatus({ kind: 'ok', msg: 'Saved Ollama base URL (persists on refresh).' });
            return;
        }

        if (providerTab === 'lmstudio') {
            actions.setLmStudioBaseUrl(draft.lmStudioBaseUrl);
            setStatus({ kind: 'ok', msg: 'Saved LM Studio base URL (persists on refresh).' });
            return;
        }

        const key = draft.cloudKeys.gemini.trim();

        if (!key) {
            if (state.providerConfig.cloudKeys.gemini) {
                setStatus({ kind: 'ok', msg: 'No changes to Gemini key.' });
            } else {
                setStatus({ kind: 'err', msg: 'Paste a Gemini key first.' });
            }
            return;
        }

        // Securely store key on backend
        try {
            const url = gw('/v1/keys/gemini');
            const { res } = await fetchWithTimeout(url, 5000, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${DEFAULT_GATEWAY_KEY}`,
                },
                body: JSON.stringify({ apiKey: key }),
            });

            if (res.status === 200) {
                actions.setCloudKey('gemini', 'SAVED');
                setDraft((prev) => ({ ...prev, cloudKeys: { gemini: '' } }));
                setShowKeys({ gemini: false });
                setStatus({ kind: 'ok', msg: 'Saved Gemini key to Secure Store.' });
            } else {
                setStatus({ kind: 'err', msg: 'Failed to save key to backend.' });
            }
        } catch (e) {
            setStatus({ kind: 'err', msg: 'Network error saving key.' });
        }
    };

    const onClearKeys = () => {
        actions.setCloudKey('gemini', '');
        setDraft((prev) => ({ ...prev, cloudKeys: { gemini: '' } }));
        setShowKeys({ gemini: false });
        setStatus({ kind: 'ok', msg: 'Cleared saved Gemini key.' });
    };

    const onTest = async () => {
        setTestStatus('idle');
        setTestMessage('');

        // 1. Cloud (Gemini) Validation
        if (providerTab === 'cloud') {
            const key = draft.cloudKeys.gemini.trim();
            if (!key && !state.providerConfig.cloudKeys.gemini) {
                setTestStatus('error');
                setTestMessage('No key provided.');
                return;
            }

            try {
                const url = gw('/v1/providers/test');
                const payload = {
                    provider: {
                        id: 'gemini',
                        type: 'cloud',
                        // If validation is running on SAVED key, send empty string so backend uses stored key.
                        apiKey: key || (state.providerConfig.cloudKeys.gemini === 'SAVED' ? '' : state.providerConfig.cloudKeys.gemini),
                    }
                };

                const { res, ms } = await fetchWithTimeout(url, 5000, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${DEFAULT_GATEWAY_KEY}`,
                    },
                    body: JSON.stringify(payload),
                });

                if (res.status === 401) {
                    setTestStatus('error');
                    setTestMessage('Gateway Auth Failed.');
                    return;
                }

                const data = await res.json().catch(() => ({}));

                if (data.status === 'ok') {
                    setTestStatus('success');
                    setTestMessage(`Valid key (${ms}ms).`);
                } else {
                    setTestStatus('error');
                    setTestMessage(data.details || 'Validation failed.');
                }
            } catch (e: any) {
                setTestStatus('error');
                setTestMessage(e?.message || 'Network error.');
            }
            return;
        }

        // 2. Local (Ollama/LM Studio) Validation
        const base = providerTab === 'ollama' ? draft.ollamaBaseUrl : draft.lmStudioBaseUrl;

        if (!isLocalOnlyUrl(base)) {
            setTestStatus('error');
            setTestMessage('Only localhost / 127.0.0.1 endpoints are allowed.');
            return;
        }

        try {
            const providerId = providerTab === 'ollama' ? 'ollama' : 'lmstudio';
            const url = gw('/v1/providers/test');
            const localPayload = {
                provider: {
                    id: providerId,
                    type: 'local',
                    baseUrl: base
                }
            };

            const { res, ms: duration } = await fetchWithTimeout(url, 4000, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${DEFAULT_GATEWAY_KEY}`
                },
                body: JSON.stringify(localPayload)
            });

            if (res.status === 401) {
                setTestStatus('error');
                setTestMessage('Gateway Auth Failed.');
                return;
            }

            const result = await res.json().catch(() => ({}));
            if (result.status === 'ok') {
                setTestStatus('success');
                setTestMessage(`Reachable (${duration}ms).`);
            } else {
                setTestStatus('error');
                setTestMessage(result.details || 'Failed.');
            }

        } catch (e: any) {
            setTestStatus('error');
            setTestMessage(e?.name === 'AbortError' ? 'Timed out.' : (e?.message || 'Failed.'));
        }
    };

    const ProviderCard = ({
        id,
        title,
        desc,
        icon: Icon,
    }: {
        id: ProviderTab;
        title: string;
        desc: string;
        icon: any;
    }) => {
        const active = providerTab === id;
        return (
            <button
                onClick={() => { setProviderTab(id); setStatus({ kind: 'idle', msg: '' }); }}
                className={`p-3 rounded border text-left transition-colors ${active ? 'border-neon/20 bg-neon/5' : 'border-border hover:bg-platinum/5'
                    }`}
            >
                <div className="flex items-center gap-2 text-neon">
                    <Icon size={16} />
                    <div className="font-medium text-sm text-platinum">{title}</div>
                </div>
                <div className="text-xs text-platinum/60 mt-1">{desc}</div>
            </button>
        );
    };

    const topTabs: SettingsTopTab[] = ['providers', 'appearance', 'about'];

    return (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50">
            <div className="w-full max-w-lg border border-border bg-panel/95 backdrop-blur rounded-xl shadow-2xl overflow-hidden">
                <div className="flex items-center justify-between px-4 py-3 border-b border-border">
                    <div className="flex items-center gap-2">
                        <Settings size={16} className="text-neon" />
                        <div className="text-sm font-semibold text-platinum">Settings</div>
                    </div>
                    <button
                        className="text-platinum/60 hover:text-platinum"
                        onClick={onClose}
                        aria-label="Close"
                    >
                        <X size={16} />
                    </button>
                </div>

                <div className="flex gap-2 px-4 py-3 border-b border-border">
                    {topTabs.map((t) => (
                        <button
                            key={t}
                            onClick={() => { setTab(t); setStatus({ kind: 'idle', msg: '' }); }}
                            className={`px-3 py-2 rounded-md text-sm border ${tab === t ? 'border-neon/20 bg-neon/5 text-neon' : 'border-border text-platinum/70 hover:bg-platinum/5'
                                }`}
                        >
                            {t[0].toUpperCase() + t.slice(1)}
                        </button>
                    ))}
                </div>

                {tab === 'providers' && (
                    <div className="space-y-3 p-4">
                        <div className="text-xs font-mono text-platinum/60 uppercase tracking-widest">Providers</div>

                        <div className="grid gap-2">
                            <ProviderCard
                                id="local"
                                title="Local"
                                desc="Local runner overview and shortcuts."
                                icon={Terminal}
                            />
                            <ProviderCard
                                id="ollama"
                                title="Ollama (Local)"
                                desc="Connect to a local Ollama instance."
                                icon={HardDrive}
                            />
                            <ProviderCard
                                id="lmstudio"
                                title="LM Studio"
                                desc="Use LM Studio OpenAI-compatible local API."
                                icon={Database}
                            />
                            <ProviderCard
                                id="cloud"
                                title="Cloud APIs"
                                desc="Configure Gemini key (stored locally)."
                                icon={Cloud}
                            />
                        </div>

                        <div className="mt-2 border border-border rounded-lg p-3 bg-black/20 space-y-3">
                            {providerTab === 'local' && (
                                <>
                                    <div className="text-xs font-mono text-platinum/60 uppercase tracking-widest">Local</div>
                                    <div className="text-xs text-platinum/60">
                                        Configure your local runner endpoints using the buttons below.
                                    </div>
                                    <div className="flex flex-wrap gap-2">
                                        <Button variant="secondary" onClick={() => setProviderTab('ollama')}>Ollama</Button>
                                        <Button variant="secondary" onClick={() => setProviderTab('lmstudio')}>LM Studio</Button>
                                    </div>
                                </>
                            )}

                            {providerTab === 'ollama' && (
                                <>
                                    <div className="text-xs font-mono text-platinum/60 uppercase tracking-widest">Ollama</div>
                                    <div className="space-y-2">
                                        <div className="text-xs text-platinum/60">Base URL</div>
                                        <Input
                                            value={draft.ollamaBaseUrl}
                                            onChange={(e) => setDraft((prev) => ({ ...prev, ollamaBaseUrl: e.target.value }))}
                                            placeholder="http://localhost:11434"
                                        />
                                        <div className="flex gap-2">
                                            <Button variant="secondary" onClick={onTest}>Test</Button>
                                            <Button variant="primary" onClick={onSave}>Save</Button>
                                        </div>
                                    </div>
                                </>
                            )}

                            {providerTab === 'lmstudio' && (
                                <>
                                    <div className="text-xs font-mono text-platinum/60 uppercase tracking-widest">LM Studio</div>
                                    <div className="space-y-2">
                                        <div className="text-xs text-platinum/60">Base URL</div>
                                        <Input
                                            value={draft.lmStudioBaseUrl}
                                            onChange={(e) => setDraft((prev) => ({ ...prev, lmStudioBaseUrl: e.target.value }))}
                                            placeholder="http://localhost:1234"
                                        />
                                        <div className="flex gap-2">
                                            <Button variant="secondary" onClick={onTest}>Test</Button>
                                            <Button variant="primary" onClick={onSave}>Save</Button>
                                        </div>
                                    </div>
                                </>
                            )}

                            {providerTab === 'cloud' && (
                                <>
                                    <div className="text-xs font-mono text-platinum/60 uppercase tracking-widest">Cloud API Keys</div>

                                    <div className="space-y-3">
                                        <div>
                                            <div className="flex items-center justify-between">
                                                <div className="text-xs text-platinum/60">Gemini API key</div>
                                                <button
                                                    className="text-[10px] font-mono text-platinum/60 hover:text-platinum"
                                                    onClick={() => setShowKeys((p) => ({ gemini: !p.gemini }))}
                                                >
                                                    {showKeys.gemini ? 'HIDE' : 'SHOW'}
                                                </button>
                                            </div>
                                            <Input
                                                type={showKeys.gemini ? 'text' : 'password'}
                                                value={draft.cloudKeys.gemini}
                                                onChange={(e) => setDraft((prev) => ({ ...prev, cloudKeys: { gemini: e.target.value } }))}
                                                placeholder={state.providerConfig.cloudKeys.gemini ? mask(state.providerConfig.cloudKeys.gemini) : 'Paste key…'}
                                            />
                                        </div>

                                        <div className="flex flex-wrap gap-2">
                                            <Button variant="secondary" onClick={onTest}>Validate</Button>
                                            <Button variant="primary" onClick={onSave}>Save</Button>
                                            <Button variant="danger" onClick={onClearKeys}>Clear keys</Button>
                                        </div>

                                        <div className="text-[10px] text-platinum/50 font-mono">
                                            Stored locally in IndexedDB. Masked by default. Validate is syntax-only (no network).
                                        </div>
                                    </div>
                                </>
                            )}

                            {status.kind !== 'idle' && (
                                <div
                                    className={`text-xs font-mono rounded px-2 py-2 border ${status.kind === 'ok'
                                        ? 'border-neon/20 text-neon bg-neon/5'
                                        : 'border-danger/20 text-danger bg-danger/5'
                                        }`}
                                >
                                    {status.msg}
                                </div>
                            )}

                            {testStatus !== 'idle' && (
                                <div
                                    className={`text-xs font-mono rounded px-2 py-2 border ${testStatus === 'success'
                                        ? 'border-neon/20 text-neon bg-neon/5'
                                        : 'border-danger/20 text-danger bg-danger/5'
                                        }`}
                                >
                                    {testMessage}
                                </div>
                            )}
                        </div>
                    </div>
                )}

                {tab === 'appearance' && (
                    <div className="p-4 text-sm text-platinum/70">Appearance settings placeholder.</div>
                )}

                {tab === 'about' && (
                    <div className="p-4 text-sm text-platinum/70">About placeholder.</div>
                )}
            </div>
        </div>
    );
};

export default ProviderSettings;
