import httpx
import asyncio

URL = "http://127.0.0.1:8787/v1/providers/test"
KEY = "terminal-treason-dev-key"

async def probe():
    payload = {
        "provider": {
            "id": "gemini",
            "type": "cloud",
            "apiKey": "dummy-key-to-trigger-syntax-check" 
        }
    }
    
    # Actually, main.py tries to call Google if we give it a dummy key.
    # It might fail with 400 (which is "API Key Invalid"), but that proves connectivity.
    # "details": "HTTP 400" is a success for "Wiring".

    try:
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                URL,
                json=payload,
                headers={"Authorization": f"Bearer {KEY}"}
            )
            print(f"Status: {resp.status_code}")
            print(f"Response: {resp.text}")
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    asyncio.run(probe())
