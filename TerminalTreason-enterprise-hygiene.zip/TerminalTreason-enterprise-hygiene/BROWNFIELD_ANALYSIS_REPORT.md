# Brownfield Analysis Report: TerminalTreason

**Generated:** 2026-01-29  
**Project:** Neon Void Terminal (TerminalTreason)  
**Codebase Version:** Phase 1 Refactor Complete (Modularization & Cloud Integration)

---

## Executive Summary

TerminalTreason is a **local-first, terminal-style AI chat application** designed for power users. The project has recently undergone a **significant architectural refactor**, transitioning from a monolithic `App.tsx` to a modular component-based structure. Additionally, the Python Gateway has been upgraded to support Cloud Providers (Gemini), adhering to the secure, local-key-storage manifesto.

### Key Findings

| Aspect | Status | Trend |
|--------|--------|-------|
| **Architecture** | Modular, clear separation of concerns | ⬆️ Improving |
| **Gateway** | Hybrid (Local + Cloud) support active | ⬆️ Improving |
| **Maintenance** | Major monolith (`App.tsx`) decomposed | 🟢 Healthy |
| **Test Coverage** | Unit tests exist but require synchronization | 🟡 Mixed |
| **Security** | Strong local-first security posture | 🟢 Stable |

---

## 1. Project Overview

### 1.1 Current State
The application is in a stable state following a "Phase 1 Refactor." The primary focus has been separating UI concerns from the core application logic and implementing the "Hybrid Gateway" pattern to support both local LLMs (via Ollama/LMStudio) and cloud keys (Gemini).

### 1.2 Visual Identity
The **"Amber Synthwave Noir"** aesthetic remains central, implemented via TailwindCSS variables and a dedicated `index.css`.

---

## 2. Technology Stack Analysis

### 2.1 Frontend Stack
- **Framework:** React 19.2.3 + Vite 6.2.0
- **Language:** TypeScript 5.8
- **Styling:** TailwindCSS 3.4
- **State:** React Context + Hooks (Native)
- **Persistence:** IndexedDB (via `idb` pattern)

### 2.2 Backend/Gateway Stack
- **Runtime:** Python 3.x
- **Framework:** FastAPI ≥0.111
- **Server:** Uvicorn
- **Client:** HTTPX (Async)
- **Capabilities:**
  - SSE Streaming
  - Provider Abstraction (Local/Cloud)
  - Secure Key Management (DPAPI/Keyring abstraction)

---

## 3. Architecture Analysis

### 3.1 Directory Structure (Updated)

```
TerminalTreason/
├── App.tsx                 # Main Controller (Reduced to ~440 lines)
├── index.tsx               # Entry Point
├── components/             # UI Modules (Extracted)
│   ├── Sidebar.tsx         # Session management
│   ├── InspectorPanel.tsx  # Logic/State visualization
│   ├── ProviderSettings.tsx # Model/Key configuration
│   ├── ConfirmDeleteModal.tsx
│   ├── Tooltip.tsx
│   ├── ErrorBoundary.tsx
│   └── Shared.tsx
├── src/
│   ├── config/             # App Configuration
│   └── store.tsx           # Global State (Context)
├── runtime/                # Python Gateway
│   ├── app/
│   │   ├── main.py         # Gateway Entry & Logic
│   │   └── secure_store.py # Key storage
│   └── requirements.txt
└── tests/                  # Test Suite
```

### 3.2 State Management
State is centralized in `src/store.tsx` using a React Context provider. The store handles:
- **Session State:** Active chat, history.
- **UI State:** Panel visibility, inspection modes.
- **Provider State:** Selected model, gateway connectivity.

### 3.3 Gateway Architecture
The `runtime/app/main.py` is now a fully functional **Model Router**:
- **Local Route:** Proxies to `localhost:1234` (Ollama/LMStudio).
- **Cloud Route:** Directly handles Google Gemini API (`generativelanguage.googleapis.com`).
- **Security:** Implements `POST /v1/keys/gemini` for secure, OS-level key storage (avoiding browser localStorage for secrets).

---

## 4. Code Quality Analysis

### 4.1 Improvements (Since Last Check)
- **Destruction of Monolith:** `App.tsx` was reduced from ~1,000 lines to ~440 lines.
- **Component Isolation:** `Sidebar`, `InspectorPanel`, and `ProviderSettings` are now standalone, improving readability and distinct ownership.

### 4.2 Known Issues
- **Type Safety:** High usage of `any` persists in `store.tsx` and some component props.
- **Test Rot:** `store.test.tsx` likely references the old monolithic state structure and needs updates to match the new `Provider` pattern.
- **Error Handling:** Gateway generic exception catching is broad; could be more specific.

---

## 5. Security Analysis

### 5.1 Strong Points
- **Secret Isolation:** API keys are never stored in `localStorage` or `cookies`. They are sent once to the Gateway, which uses OS-secure storage (e.g., Windows Credentials/DPAPI).
- **Traffic Hygiene:** Browser only talks to `localhost` (Gateway/Frontend). External calls originate *only* from the Python Gateway.
- **Confirmation:** Destructive actions (Deleting sessions) require explicit confirmation.

### 5.2 Attention Required
- **CORS:** Gateway allows `*` (Star) origin in some configs (though `main.py` shows specific `ALLOWED_ORIGINS` list, worth verifying in prod).
- **Input Validation:** Ensure Gateway validates `providerId` and `modelName` strictly to prevent injection or SSRF-like behavior (though low risk in local-first app).

---

## 6. Recommendations

### 6.1 Immediate
1. **Fix Test Suite:** Run `vitest` and repair `store.test.tsx` to align with the new Context shape.
2. **Type Hardening:** Replace `(base as any)` casts in `store.tsx` with proper Interfaces.

### 6.2 Short Term
1. **Response Parsing:** Ensure Frontend robustly handles Gateway errors (e.g., when Gemini key is invalid).
2. **Logging:** Improve Gateway logs to separate "Application Logic" errors from "Network/Provider" errors.

---

_Analysis performed by Antigravity on 2026-01-29_
