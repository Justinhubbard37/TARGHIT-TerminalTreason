Optional gateway patch (root route)
Copy/overwrite:
- app/main.py -> runtime/app/main.py (where your FastAPI gateway code lives)

Restart the gateway.
Then http://127.0.0.1:8787/ will return the same JSON as /v1/health
