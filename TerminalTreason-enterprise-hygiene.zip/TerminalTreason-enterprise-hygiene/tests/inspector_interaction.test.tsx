import { describe, it, expect, vi } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import App from '../App';
import { StoreProvider } from '../src/store';
import React from 'react';

// Mock scrollIntoView
window.HTMLElement.prototype.scrollIntoView = vi.fn();

describe('Inspector Interaction', () => {
  it('should render inspector with default logs tab', async () => {
    render(
      <StoreProvider>
        <App />
      </StoreProvider>
    );

    // Inspector should show logs tab as default/active
    const logsTab = await screen.findByRole('button', { name: /logs/i });
    expect(logsTab).toBeDefined();
  });

  it('should switch to vars tab when clicked', async () => {
    render(
      <StoreProvider>
        <App />
      </StoreProvider>
    );

    // Click vars tab
    const varsTab = await screen.findByRole('button', { name: /vars/i });
    fireEvent.click(varsTab);

    // Should show message about selecting a message
    expect(await screen.findByText(/Select a message to view variables/i)).toBeDefined();
  });

  it('should display log entries in logs tab', async () => {
    render(
      <StoreProvider>
        <App />
      </StoreProvider>
    );

    // Logs tab should show mock log entries
    // These come from MOCK_LOGS in constants.ts
    const logsTab = await screen.findByRole('button', { name: /logs/i });
    fireEvent.click(logsTab);

    // Should see log levels like INFO, WARN, etc.
    // Note: The exact content depends on what's in MOCK_LOGS
  });
});
