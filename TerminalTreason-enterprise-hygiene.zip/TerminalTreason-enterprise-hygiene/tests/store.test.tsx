import { describe, it, expect } from 'vitest';
import { renderHook, act } from '@testing-library/react';
import { StoreProvider, useStore, ChatMessage } from '../src/store';
import React, { ReactNode } from 'react';

const wrapper = ({ children }: { children: ReactNode }) => (
  <StoreProvider>{children}</StoreProvider>
);

describe('UI State Store', () => {
  it('should initialize with default values', () => {
    const { result } = renderHook(() => useStore(), { wrapper });

    // Default provider should be 'local'
    expect(result.current.state.currentProvider).toBe('local');

    // With no initial config, sessions and activeSessionId start empty
    expect(result.current.state.sessions).toEqual([]);
    expect(result.current.state.activeSessionId).toBeNull();
  });

  it('should update current provider', () => {
    const { result } = renderHook(() => useStore(), { wrapper });

    act(() => {
      result.current.actions.setCurrentProvider('cloud');
    });

    expect(result.current.state.currentProvider).toBe('cloud');
  });

  it('should create a new session and set it as active', () => {
    const { result } = renderHook(() => useStore(), { wrapper });

    let newSessionId: string;
    act(() => {
      newSessionId = result.current.actions.createSession();
    });

    expect(result.current.state.sessions).toHaveLength(1);
    expect(result.current.state.activeSessionId).toBe(newSessionId!);
    expect(result.current.state.sessions[0].title).toBe('New chat');
  });

  it('should update active session', () => {
    const { result } = renderHook(() => useStore(), { wrapper });

    // First create two sessions
    let sessionId1: string;
    let sessionId2: string;
    act(() => {
      sessionId1 = result.current.actions.createSession();
    });
    act(() => {
      sessionId2 = result.current.actions.createSession();
    });

    // sessionId2 should be active (most recent)
    expect(result.current.state.activeSessionId).toBe(sessionId2!);

    // Switch to first session
    act(() => {
      result.current.actions.setActiveSession(sessionId1!);
    });

    expect(result.current.state.activeSessionId).toBe(sessionId1!);
  });

  it('should add messages to a session', () => {
    const { result } = renderHook(() => useStore(), { wrapper });

    // Create a session first
    let sessionId: string;
    act(() => {
      sessionId = result.current.actions.createSession();
    });

    const initialMessages = result.current.state.messagesBySession[sessionId!] || [];
    expect(initialMessages).toHaveLength(0);

    const newMessage: ChatMessage = {
      id: 'msg-1',
      role: 'user',
      content: 'Hello, world!',
      createdAt: Date.now(),
    };

    act(() => {
      result.current.actions.addMessage(sessionId!, newMessage);
    });

    const messages = result.current.state.messagesBySession[sessionId!];
    expect(messages).toHaveLength(1);
    expect(messages[0]).toEqual(newMessage);
  });

  it('should delete a session', () => {
    const { result } = renderHook(() => useStore(), { wrapper });

    // Create a session
    let sessionId: string;
    act(() => {
      sessionId = result.current.actions.createSession();
    });

    expect(result.current.state.sessions).toHaveLength(1);
    expect(result.current.state.activeSessionId).toBe(sessionId!);

    // Delete the session
    act(() => {
      result.current.actions.deleteSession(sessionId!);
    });

    expect(result.current.state.sessions).toHaveLength(0);
    expect(result.current.state.activeSessionId).toBeNull();
  });

  it('should rename a session', () => {
    const { result } = renderHook(() => useStore(), { wrapper });

    // Create a session
    let sessionId: string;
    act(() => {
      sessionId = result.current.actions.createSession();
    });

    expect(result.current.state.sessions[0].title).toBe('New chat');

    // Rename it
    act(() => {
      result.current.actions.renameSession(sessionId!, 'My Custom Session');
    });

    expect(result.current.state.sessions[0].title).toBe('My Custom Session');
  });

  it('should clear messages from a session', () => {
    const { result } = renderHook(() => useStore(), { wrapper });

    // Create a session and add messages
    let sessionId: string;
    act(() => {
      sessionId = result.current.actions.createSession();
    });

    act(() => {
      result.current.actions.addMessage(sessionId!, {
        id: 'msg-1',
        role: 'user',
        content: 'First message',
        createdAt: Date.now(),
      });
      result.current.actions.addMessage(sessionId!, {
        id: 'msg-2',
        role: 'assistant',
        content: 'Response',
        createdAt: Date.now(),
      });
    });

    expect(result.current.state.messagesBySession[sessionId!]).toHaveLength(2);

    // Clear messages
    act(() => {
      result.current.actions.clearMessages(sessionId!);
    });

    expect(result.current.state.messagesBySession[sessionId!]).toHaveLength(0);
  });

  it('should update provider base URLs', () => {
    const { result } = renderHook(() => useStore(), { wrapper });

    const newOllamaUrl = 'http://127.0.0.1:9999';
    const newLmStudioUrl = 'http://127.0.0.1:8888';

    act(() => {
      result.current.actions.setProviderBaseUrl('ollama', newOllamaUrl);
    });

    expect(result.current.state.providerConfig.ollamaBaseUrl).toBe(newOllamaUrl);

    act(() => {
      result.current.actions.setProviderBaseUrl('lmstudio', newLmStudioUrl);
    });

    expect(result.current.state.providerConfig.lmStudioBaseUrl).toBe(newLmStudioUrl);
  });

  it('should set cloud API keys', () => {
    const { result } = renderHook(() => useStore(), { wrapper });

    act(() => {
      result.current.actions.setCloudKey('gemini', 'test-api-key-123');
    });

    expect(result.current.state.providerConfig.cloudKeys.gemini).toBe('test-api-key-123');
  });

  it('should update model for a provider', () => {
    const { result } = renderHook(() => useStore(), { wrapper });

    act(() => {
      result.current.actions.setModelForProvider('local', 'llama3.2:7b');
    });

    expect(result.current.state.modelByProvider.local).toBe('llama3.2:7b');

    act(() => {
      result.current.actions.setModelForProvider('cloud', 'gemini-2.0-flash');
    });

    expect(result.current.state.modelByProvider.cloud).toBe('gemini-2.0-flash');
  });

  it('should toggle UI collapse states', () => {
    const { result } = renderHook(() => useStore(), { wrapper });

    // Default states
    expect(result.current.state.leftCollapsed).toBe(false);
    expect(result.current.state.rightCollapsed).toBe(false);

    act(() => {
      result.current.actions.setLeftCollapsed(true);
    });

    expect(result.current.state.leftCollapsed).toBe(true);

    act(() => {
      result.current.actions.setRightCollapsed(true);
    });

    expect(result.current.state.rightCollapsed).toBe(true);
  });

  it('should switch view modes', () => {
    const { result } = renderHook(() => useStore(), { wrapper });

    expect(result.current.state.viewMode).toBe('chat');

    act(() => {
      result.current.actions.setViewMode('settings');
    });

    expect(result.current.state.viewMode).toBe('settings');

    act(() => {
      result.current.actions.setViewMode('chat');
    });

    expect(result.current.state.viewMode).toBe('chat');
  });

  // New tests for added functionality

  it('should update composer text', () => {
    const { result } = renderHook(() => useStore(), { wrapper });

    expect(result.current.state.composerText).toBe('');

    act(() => {
      result.current.actions.setComposerText('Hello AI');
    });

    expect(result.current.state.composerText).toBe('Hello AI');
  });

  it('should send message and clear composer', () => {
    const { result } = renderHook(() => useStore(), { wrapper });

    // Create a session first
    let sessionId: string;
    act(() => {
      sessionId = result.current.actions.createSession();
    });

    // Send a message
    act(() => {
      result.current.actions.sendMessage('Hello AI');
    });

    // Composer should be cleared
    expect(result.current.state.composerText).toBe('');

    // Message should be added to session
    const messages = result.current.state.messagesBySession[sessionId!];
    expect(messages).toHaveLength(1);
    expect(messages[0].content).toBe('Hello AI');
    expect(messages[0].role).toBe('user');
  });

  it('should toggle left and right collapsed states', () => {
    const { result } = renderHook(() => useStore(), { wrapper });

    expect(result.current.state.leftCollapsed).toBe(false);
    expect(result.current.state.rightCollapsed).toBe(false);

    act(() => {
      result.current.actions.toggleLeftCollapsed();
    });
    expect(result.current.state.leftCollapsed).toBe(true);

    act(() => {
      result.current.actions.toggleRightCollapsed();
    });
    expect(result.current.state.rightCollapsed).toBe(true);

    act(() => {
      result.current.actions.toggleLeftCollapsed();
    });
    expect(result.current.state.leftCollapsed).toBe(false);
  });

  it('should set selected message', () => {
    const { result } = renderHook(() => useStore(), { wrapper });

    expect(result.current.state.selectedMessage).toBeNull();

    const testMessage: ChatMessage = {
      id: 'test-msg',
      role: 'assistant',
      content: 'Test response',
      createdAt: Date.now(),
    };

    act(() => {
      result.current.actions.setSelectedMessage(testMessage);
    });

    expect(result.current.state.selectedMessage).toEqual(testMessage);

    act(() => {
      result.current.actions.setSelectedMessage(null);
    });

    expect(result.current.state.selectedMessage).toBeNull();
  });

  it('should set model for current provider using setModel', () => {
    const { result } = renderHook(() => useStore(), { wrapper });

    // Current provider is 'local' by default
    act(() => {
      result.current.actions.setModel('custom-model');
    });

    expect(result.current.state.modelByProvider.local).toBe('custom-model');
    expect(result.current.state.modelName).toBe('custom-model');
  });
});
