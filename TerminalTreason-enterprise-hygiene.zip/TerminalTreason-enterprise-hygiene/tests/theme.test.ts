import { describe, it, expect, beforeAll } from 'vitest';
import fs from 'fs';
import path from 'path';

describe('Theme Integration', () => {
  let cssContent: string;

  beforeAll(() => {
    cssContent = fs.readFileSync(path.resolve(__dirname, '../index.css'), 'utf-8');
  });

  it('should define the Amber Synthwave Noir color palette', () => {
    expect(cssContent).toContain('--color-bg-obsidian: #0A0C10');
    expect(cssContent).toContain('--color-bg-steel: #141824');
    expect(cssContent).toContain('--color-border: #404656');
    expect(cssContent).toContain('--color-focus-blue: #2F80ED');
    expect(cssContent).toContain('--color-warning-red: #E05B3C');
    expect(cssContent).toContain('--color-text-white: #F2F4F8');
  });

  it('should apply base background and text colors', () => {
    expect(cssContent).toContain('background-color: var(--color-bg-obsidian)');
    expect(cssContent).toContain('color: var(--color-text-white)');
  });
});
