import { describe, it, expect, vi } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import App from '../App';
import { StoreProvider } from '../src/store';
import React from 'react';

// Mock scrollIntoView
window.HTMLElement.prototype.scrollIntoView = vi.fn();

describe('Model Picker', () => {
  it('should show Local/Cloud toggle in model picker area', async () => {
    render(
      <StoreProvider>
        <App />
      </StoreProvider>
    );

    // The model picker shows "Local" text by default (multiple elements may match)
    const localTexts = await screen.findAllByText(/Local/i);
    expect(localTexts.length).toBeGreaterThan(0);
  });

  it('should show model picker button in header', async () => {
    render(
      <StoreProvider>
        <App />
      </StoreProvider>
    );

    // Find the model picker button - it contains the current model name
    // Default model should be visible
    const buttons = await screen.findAllByRole('button');
    expect(buttons.length).toBeGreaterThan(0);
  });
});

describe('Settings', () => {
  it('should have settings button accessible', async () => {
    render(
      <StoreProvider>
        <App />
      </StoreProvider>
    );

    // Settings functionality exists - tested via store tests
    // This is a smoke test that the app renders
    expect(screen.getByText(/TerminalTreason/i)).toBeDefined();
  });
});
