import { describe, it, expect, vi } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import App from '../App';
import { StoreProvider } from '../src/store';
import React from 'react';

// Mock scrollIntoView
window.HTMLElement.prototype.scrollIntoView = vi.fn();

describe('Session Management', () => {
  it('should show empty state when no sessions exist', async () => {
    render(
      <StoreProvider>
        <App />
      </StoreProvider>
    );

    // With no sessions, should show the welcome/empty state with app title
    expect(await screen.findByText(/TerminalTreason/i)).toBeDefined();
  });

  it('should show sidebar with TerminalTreason branding', async () => {
    render(
      <StoreProvider>
        <App />
      </StoreProvider>
    );

    // Sidebar shows TerminalTreason branding (multiple elements may match)
    const terminalTexts = await screen.findAllByText(/Terminal/i);
    expect(terminalTexts.length).toBeGreaterThan(0);
  });

  it('should show session search input', async () => {
    render(
      <StoreProvider>
        <App />
      </StoreProvider>
    );

    // Sidebar has a search sessions input
    const searchInput = await screen.findByPlaceholderText(/Search sessions/i);
    expect(searchInput).toBeDefined();
  });

  it('should show NO SESSION badge when no active session', async () => {
    render(
      <StoreProvider>
        <App />
      </StoreProvider>
    );

    // Header shows NO SESSION when no session is active
    expect(await screen.findByText(/NO SESSION/i)).toBeDefined();
  });
});
