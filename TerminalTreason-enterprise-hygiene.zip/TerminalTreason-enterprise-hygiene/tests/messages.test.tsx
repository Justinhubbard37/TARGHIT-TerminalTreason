import { describe, it, expect, vi } from 'vitest';
import { render, screen, fireEvent, act } from '@testing-library/react';
import App from '../App';
import { StoreProvider } from '../src/store';
import React from 'react';

// Mock scrollIntoView as it's not implemented in jsdom
window.HTMLElement.prototype.scrollIntoView = vi.fn();

describe('Message Flow', () => {
  it('should render the chat interface with input field', async () => {
    render(
      <StoreProvider>
        <App />
      </StoreProvider>
    );

    // The input should have a placeholder for typing prompts
    const input = await screen.findByPlaceholderText(/Type a prompt/i);
    expect(input).toBeDefined();
  });

  it('should have a Send button', async () => {
    render(
      <StoreProvider>
        <App />
      </StoreProvider>
    );

    const sendButton = await screen.findByRole('button', { name: /send/i });
    expect(sendButton).toBeDefined();
  });

  it('should show empty state when no messages exist', async () => {
    render(
      <StoreProvider>
        <App />
      </StoreProvider>
    );

    // Empty state shows "TerminalTreason" heading and prompt to start
    expect(await screen.findByText(/TerminalTreason/i)).toBeDefined();
    expect(await screen.findByText(/Start a new session/i)).toBeDefined();
  });

  it('should allow typing in the input field', async () => {
    render(
      <StoreProvider>
        <App />
      </StoreProvider>
    );

    const input = await screen.findByPlaceholderText(/Type a prompt/i);

    await act(async () => {
      fireEvent.change(input, { target: { value: 'Hello AI' } });
    });

    expect((input as HTMLInputElement).value).toBe('Hello AI');
  });
});
