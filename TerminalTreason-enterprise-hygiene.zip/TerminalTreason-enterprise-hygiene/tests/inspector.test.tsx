import { describe, it, expect, vi } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import App from '../App';
import { StoreProvider } from '../src/store';
import React from 'react';

// Mock scrollIntoView as it's not implemented in jsdom
window.HTMLElement.prototype.scrollIntoView = vi.fn();

describe('Inspector Panel', () => {
  it('should render the inspector panel with tabs', async () => {
    render(
      <StoreProvider>
        <App />
      </StoreProvider>
    );

    // Inspector should show "INSPECTOR" heading or tabs on larger screens
    // On desktop view, the inspector panel should have log/vars/trace tabs
    const logsTab = await screen.findByRole('button', { name: /logs/i });
    expect(logsTab).toBeDefined();
  });

  it('should switch between inspector tabs', async () => {
    render(
      <StoreProvider>
        <App />
      </StoreProvider>
    );

    // Find and click the vars tab
    const varsTab = await screen.findByRole('button', { name: /vars/i });
    fireEvent.click(varsTab);

    // Should show "Select a message to view variables" when no message selected
    expect(await screen.findByText(/Select a message to view variables/i)).toBeDefined();

    // Switch to trace tab
    const traceTab = await screen.findByRole('button', { name: /trace/i });
    fireEvent.click(traceTab);

    // Should show trace placeholder
    expect(await screen.findByText(/Trace view placeholder/i)).toBeDefined();
  });
});
