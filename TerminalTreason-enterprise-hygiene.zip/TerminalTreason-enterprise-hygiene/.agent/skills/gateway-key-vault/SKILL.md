---
name: "gateway-key-vault"
description: "Fixes TerminalTreason Gemini key persistence: secure local gateway key storage, /v1/keys/gemini endpoints, remove browser key transport from chat requests, resolve 500 save-key errors."
triggers:
  - "failed to save key"
  - "secure store"
  - "keys/gemini"
  - "X-Gemini-Key"
  - "gateway has no stored gemini key"
  - "500 Internal Server Error"
---

# Gateway Key Vault Skill

This skill documents the secure key storage mechanism implemented in the TerminalTreason gateway.

## Implementation Details

The vault uses **Windows DPAPI** (Data Protection API) via `ctypes` to encrypt API keys before writing them to disk. This ensures that:
1.  Keys can only be decrypted by the user context that encrypted them.
2.  Keys are not stored in plain text.
3.  Keys are not accessible to the frontend client after saving.

### File Location
- **Path**: `secrets.dat` (relative to the gateway execution directory).
- **Format**: JSON mapping of `provider_id` -> `base64_encoded_ciphertext`.

### Python Interface (`app/main.py`)

```python
class KeyStore:
    def save_key(self, provider: str, key: str): ...
    def get_key(self, provider: str) -> Optional[str]: ...
```

### HTTP Interface

#### Save Key
- **Endpoint**: `POST /v1/keys/{provider}`
- **Body**: `{ "apiKey": "..." }`
- **Auth**: Requires Gateway Bearer Token.

#### Usage
The frontend should:
1.  Accept input from user.
2.  POST directly to this endpoint.
3.  Clear the input field.
4.  Store a placeholder (e.g., `'SAVED'`) in local state to indicate presence.

## Security Rules
- **NEVER** return the decrypted key in any API response.
- **NEVER** log the decrypted key.
- **ALWAYS** validate the key server-side (optional ping) before saving if possible.

That `::contentReference[oaicite:…]…` line is **UI citation metadata**. It is **not** part of what you should paste into `SKILL.md`.

Use the **Copy code** button on the code block. That copies **only** the code block and **not** the `contentReference` garbage.

Paste this into `SKILL.md` (and only this):

````md
## /v1/providers/test payload compatibility (422 schema mismatch fix)

**Symptom:** `POST /v1/providers/test` returns **422 Unprocessable Content** complaining that root fields `id`, `type`, `name`, `status` are missing, while the UI sends a nested payload.

**UI (current) payload shape (nested):**

```json
{ "provider": { "id": "gemini", "type": "cloud", "apiKey": "<key>" } }
````

**Legacy/flat payload shape (some gateways expect this):**

```json
{ "id": "gemini", "type": "cloud", "name": "Gemini", "status": "active" }
```

**Required behavior:**

* `/v1/providers/test` MUST accept **both** shapes.
* For the nested shape, treat `provider.id` and `provider.type` as the canonical values; do **not** require `name` or `status`.
* When `provider.apiKey` is present, use it only for the test call; otherwise load the key from the gateway secure store.
* Keep gateway auth (Bearer token) enforced.