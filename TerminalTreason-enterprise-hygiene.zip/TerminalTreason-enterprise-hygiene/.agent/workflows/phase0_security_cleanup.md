# Phase 0 — Security Cleanup (Enterprise)

You are operating in AntiGravity IDE with Secure Mode enabled.

Goal: Harden the repo so secrets and bulky artifacts never ship again. Do NOT change app behavior.

Workflow:
1) Recon (read-only):
   - Identify any secrets in workspace (.env.local, secrets.dat, *.dat, tokens/keys).
   - Determine if any are tracked by git.
   - Identify bulky artifacts that should never be shipped (dist, coverage, __pycache__, *.bak, runtime/.venv).

2) Produce artifacts:
   - Task List (checkboxes, ordered)
   - Implementation Plan (exact files/commands, risks, rollback)
   - STOP and request approval before making changes or running terminal commands.

Rules:
- Never print full secrets; mask values (first 4 + last 4).
- No destructive commands without approval.
- Minimal diffs only.