/**
 * Represents a chat session with metadata including title, folder, and tags.
 */
export interface Session {
  id: string;
  title: string;
  updatedAt: string;
  updatedAtIso?: string;
  tags?: string[];
  folder?: string;
}

/**
 * A single message in the chat history, including role, content, and optional metadata.
 */
export interface Message {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: string;
  timestampIso?: string;
  meta?: {
    provider: string;
    model: string;
    tokens: number;
    latency: number;
  };
}

/**
 * Structure for application logs displayed in the Inspector Panel.
 */
export interface LogEntry {
  id: string;
  ts: string;
  level: 'INFO' | 'WARN' | 'ERROR' | 'DEBUG';
  message: string;
}

/**
 * Health and connection status of an AI provider (e.g., Ollama).
 */
export interface ProviderStatus {
  id: string;
  name: string;
  status: 'connected' | 'disconnected' | 'error';
  latency: number;
}

export type ViewMode = 'chat' | 'settings';
export type ComposerMode = 'chat' | 'command';
export type SettingsTab = 'ollama' | 'lmstudio' | 'cloud';

/**
 * Global state interface for the application, tracking view mode, streaming status, and UI flags.
 */
export interface AppState {
  currentView: ViewMode;
  activeSessionId: string;
  isStreaming: boolean;

  // Mobile/Overlay States
  isMobileSessionOpen: boolean;
  isMobileLogsOpen: boolean;
  isModelPickerOpen: boolean;
  isHealthOpen: boolean;

  // Selection
  selectedMessageId: string | null; // For debug inspector
}
